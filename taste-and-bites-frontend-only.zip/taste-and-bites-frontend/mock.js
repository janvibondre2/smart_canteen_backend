/* Demo-only mock of the FastAPI + Supabase backend (in-memory). */
(function () {
  const now = Date.now(), day = 864e5, iso = d => new Date(now - d * day).toISOString();
  const svg = (e, a, b) => 'data:image/svg+xml,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="400" height="300"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient></defs><rect width="400" height="300" fill="url(#g)"/><text x="200" y="185" font-size="120" text-anchor="middle">${e}</text></svg>`);
  window.TB_FALLBACK = svg('🍽️', '#E5F3E6', '#BFE3C2');
  const cats = [[1, 'Meals'], [2, 'Snacks'], [3, 'Beverages'], [4, 'Desserts']].map(([id, name]) => ({ id, name }));
  const F = [[1, 'Paneer Thali', 'Paneer butter masala, roti, rice & salad', 120, 1, '🍛', 20, 1], [2, 'Veg Biryani', 'Fragrant basmati with cool raita', 90, 1, '🍚', 12, 1], [3, 'Masala Dosa', 'Crisp dosa, potato filling, chutneys', 60, 1, '🥞', 3, 1],
    [4, 'Veg Burger', 'Crunchy patty with melted cheese', 70, 2, '🍔', 15, 1], [5, 'Samosa (2 pc)', 'Golden, spicy and served hot', 30, 2, '🥟', 40, 1], [6, 'Cheese Sandwich', 'Grilled with butter', 50, 2, '🥪', 0, 0],
    [7, 'Masala Chai', 'Ginger-cardamom tea', 15, 3, '☕', 50, 1], [8, 'Cold Coffee', 'Thick, chilled and creamy', 60, 3, '🥤', 4, 1], [9, 'Gulab Jamun (2 pc)', 'Warm and syrupy classic', 40, 4, '🍮', 18, 1], [10, 'Walnut Brownie', 'Fudgy chocolate square', 55, 4, '🍫', 9, 1]]
    .map(([id, name, description, price, category_id, e, stock_quantity, available], i) => ({ id, name, description, price, category_id, available: !!available, stock_quantity, image_url: svg(e, ['#FFE7D6', '#E5F3E6', '#FFF1CC', '#F3E1F7'][i % 4], ['#FFB98A', '#9ED3A3', '#F5CF73', '#D9B0E6'][i % 4]) }));
  const D = {
    foods: F, cart: {}, nid: 104, cid: 1, nn: 10,
    orders: [
      { id: 101, user_id: 'u1', total_amount: 150, pickup_time: iso(1), order_status: 'COMPLETED', payment_status: 'SUCCESS', created_at: iso(1), items: [[1, 1, 120], [7, 2, 15]] },
      { id: 102, user_id: 'u1', total_amount: 90, pickup_time: new Date(now + 36e5).toISOString(), order_status: 'PREPARING', payment_status: 'SUCCESS', created_at: iso(0), items: [[8, 1, 60], [5, 1, 30]] },
      { id: 103, user_id: 'u2', total_amount: 180, pickup_time: new Date(now + 54e5).toISOString(), order_status: 'PLACED', payment_status: 'SUCCESS', created_at: iso(0), items: [[2, 2, 90]] },
      { id: 98, user_id: 'u2', total_amount: 250, pickup_time: iso(3), order_status: 'COMPLETED', payment_status: 'SUCCESS', created_at: iso(3), items: [[1, 2, 120], [9, 1, 40]] },
      { id: 99, user_id: 'u3', total_amount: 140, pickup_time: iso(2), order_status: 'COMPLETED', payment_status: 'SUCCESS', created_at: iso(2), items: [[4, 2, 70]] },
      { id: 97, user_id: 'u3', total_amount: 310, pickup_time: iso(5), order_status: 'COMPLETED', payment_status: 'SUCCESS', created_at: iso(5), items: [[1, 2, 120], [10, 1, 55], [7, 1, 15]] },
      { id: 96, user_id: 'u2', total_amount: 200, pickup_time: iso(4), order_status: 'COMPLETED', payment_status: 'SUCCESS', created_at: iso(4), items: [[2, 2, 90], [7, 1, 15]] }],
    notes: [{ id: 1, user_id: 'u1', message: 'Your order #102 status is now PREPARING', is_read: false, created_at: iso(0) }, { id: 2, user_id: 'u1', message: 'Your order #101 status is now COMPLETED', is_read: true, created_at: iso(1) }],
    fb: [{ id: 1, user_id: 'u2', order_id: 98, rating: 5, comment: 'Loved the thali!', created_at: iso(3) }, { id: 2, user_id: 'u3', order_id: 99, rating: 4, comment: 'Quick pickup', created_at: iso(2) }],
    profiles: { u1: { id: 'u1', name: 'Riya Sharma', phone: '+91 98765 43210', role: 'student' }, adm: { id: 'adm', name: 'Kunal Mehta', phone: '+91 90000 11111', role: 'admin' } }
  };
  const STAT = ['PLACED', 'CONFIRMED', 'PREPARING', 'READY', 'COMPLETED', 'CANCELLED'];
  const note = (uid, message) => D.notes.unshift({ id: ++D.nn, user_id: uid, message, is_read: false, created_at: new Date().toISOString() });
  const strip = o => { const { items, ...r } = o; return r };
  const ord = id => D.orders.find(o => o.id == id);
  function route(m, p, q) {
    let x;
    if (p === '/categories') return cats;
    if (p === '/food-items') return D.foods;
    if ((x = p.match(/^\/cart\/items\/(\d+)$/))) {
      const id = +x[1]; for (const k in D.cart) { const it = D.cart[k].find(i => i.id === id); if (it) { if (m === 'PUT') it.quantity = +q.quantity; else D.cart[k] = D.cart[k].filter(i => i.id !== id); return { message: 'ok' } } } return { message: 'not found' }
    }
    if ((x = p.match(/^\/cart\/([\w-]+)\/items$/))) { const c = D.cart[x[1]] = D.cart[x[1]] || []; c.push({ id: D.cid++, cart_id: 1, food_item_id: +q.food_item_id, quantity: +q.quantity || 1 }); return { message: 'Item added to cart' } }
    if ((x = p.match(/^\/cart\/([\w-]+)$/))) { const c = D.cart[x[1]] || []; return c.length ? { cart_id: 1, items: c } : { message: 'Cart is empty' } }
    if ((x = p.match(/^\/checkout\/([\w-]+)$/))) {
      const c = D.cart[x[1]] || []; if (!c.length) return { message: 'Cart is empty' };
      const bad = c.find(i => !D.foods.find(f => f.id === i.food_item_id).available); if (bad) return { message: D.foods.find(f => f.id === bad.food_item_id).name + ' is not available' };
      const items = c.map(i => { const f = D.foods.find(f => f.id === i.food_item_id); return [f.id, i.quantity, f.price] }), total = items.reduce((a, [, qn, pr]) => a + qn * pr, 0), id = D.nid++;
      D.orders.unshift({ id, user_id: x[1], total_amount: total, pickup_time: q.pickup_time, order_status: 'PLACED', payment_status: 'PENDING', created_at: new Date().toISOString(), items });
      D.cart[x[1]] = []; return { message: 'Order placed successfully', order_id: id, total_amount: total, pickup_time: q.pickup_time, order_status: 'PLACED', payment_status: 'PENDING' }
    }
    if ((x = p.match(/^\/payment\/(\d+)$/))) { const o = ord(x[1]); o.payment_status = 'SUCCESS'; return { message: 'Payment successful', order_id: o.id, payment_status: 'SUCCESS', transaction_id: 'TEST_TXN_' + o.id } }
    if ((x = p.match(/^\/inventory\/reduce\/(\d+)$/))) {
      const o = ord(x[1]); for (const [fid, qn] of o.items) { if (D.foods.find(f => f.id === fid).stock_quantity < qn) return { message: 'Not enough stock for food item ' + fid } }
      o.items.forEach(([fid, qn]) => D.foods.find(f => f.id === fid).stock_quantity -= qn); return { message: 'Inventory updated successfully' }
    }
    if ((x = p.match(/^\/my-orders\/([\w-]+)$/))) return D.orders.filter(o => o.user_id === x[1]).map(strip);
    if ((x = p.match(/^\/orders\/(\d+)\/details$/))) { const o = ord(x[1]); return { order: strip(o), items: o.items.map(([fid, qn, pr], i) => { const f = D.foods.find(f => f.id === fid); return { id: i, food_item_id: fid, quantity: qn, price: pr, food_items: { name: f.name, image_url: f.image_url } } }) } }
    if ((x = p.match(/^\/orders\/(\d+)\/cancel$/))) { const o = ord(x[1]); if (o.order_status !== 'PLACED') return { message: 'Order cannot be cancelled now' }; o.order_status = 'CANCELLED'; note(o.user_id, `Your order #${o.id} has been cancelled`); return { message: 'Order cancelled successfully' } }
    if ((x = p.match(/^\/notifications\/(\d+)\/read$/))) { D.notes.find(n => n.id == x[1]).is_read = true; return { message: 'Notification marked as read' } }
    if ((x = p.match(/^\/notifications\/([\w-]+)$/))) return D.notes.filter(n => n.user_id === x[1]);
    if ((x = p.match(/^\/feedback\/user\/([\w-]+)$/))) return D.fb.filter(f => f.user_id === x[1]);
    if ((x = p.match(/^\/feedback\/([\w-]+)\/(\d+)$/))) { const o = ord(x[2]); if (o.order_status !== 'COMPLETED') return { message: 'Feedback can be given only after order is completed' }; D.fb.unshift({ id: D.fb.length + 1, user_id: x[1], order_id: o.id, rating: +q.rating, comment: q.comment || '', created_at: new Date().toISOString() }); return { message: 'Feedback submitted successfully' } }
    if ((x = p.match(/^\/profile\/([\w-]+)$/))) { const pr = D.profiles[x[1]]; if (m === 'PUT') { if (q.name != null) pr.name = q.name; if (q.phone != null) pr.phone = q.phone; return { message: 'Profile updated successfully', profile: pr } } return pr }
    if (p === '/orders') return D.orders.map(strip);
    if ((x = p.match(/^\/admin\/orders\/(\d+)\/status$/))) { const o = ord(x[1]); o.order_status = q.status; note(o.user_id, `Your order #${o.id} status is now ${q.status}`); return { message: 'Order status updated', order_status: q.status } }
    if (p === '/admin/analytics/sales') { const s = D.orders.filter(o => o.payment_status === 'SUCCESS'); return { total_transactions: s.length, total_sales: s.reduce((a, o) => a + o.total_amount, 0) } }
    if (p === '/admin/analytics/orders') { const c = Object.fromEntries(STAT.map(k => [k, 0])); D.orders.forEach(o => c[o.order_status]++); return { total_orders: D.orders.length, orders_by_status: c } }
    if (p === '/admin/analytics/inventory') return D.foods.map(f => ({ id: f.id, food_item_id: f.id, quantity: f.stock_quantity, food_items: { name: f.name } }));
    if (p === '/admin/feedback') return { total_feedback: D.fb.length, average_rating: +(D.fb.reduce((a, f) => a + f.rating, 0) / D.fb.length).toFixed(2), feedback: D.fb };
    return { message: 'Not found' };
  }
  const real = window.fetch.bind(window);
  window.fetch = async (url, opts = {}) => {
    const u = new URL(url, location.href); if (u.origin !== 'http://mock.local') return real(url, opts);
    await new Promise(r => setTimeout(r, 120));
    const data = route((opts.method || 'GET').toUpperCase(), u.pathname, Object.fromEntries(u.searchParams));
    return { ok: true, status: 200, json: async () => JSON.parse(JSON.stringify(data)) };
  };
  let session = null; const ls = [];
  const emit = () => ls.forEach(cb => cb('SIGNED_IN', session));
  window.supabase = { createClient: () => ({ auth: {
    signInWithPassword: async ({ email }) => { session = { user: { id: /admin/i.test(email) ? 'adm' : 'u1', email } }; setTimeout(emit, 50); return { data: { session }, error: null } },
    signUp: async function (a) { return this.signInWithPassword(a) },
    signOut: async () => { session = null; ls.forEach(cb => cb('SIGNED_OUT', null)); return {} },
    onAuthStateChange: cb => { ls.push(cb); return { data: { subscription: { unsubscribe() { } } } } },
    getSession: async () => ({ data: { session } }) } }) };
  window.TB_CONFIG = { API_URL: 'http://mock.local', SUPABASE_URL: 'x', SUPABASE_ANON_KEY: 'x' };
})();
