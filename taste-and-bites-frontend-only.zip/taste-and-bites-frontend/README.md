# Taste & Bites — Frontend only

Open `index.html` in a browser (double-click). No server, install or backend needed.
It runs on sample data via `mock.js`. Use the green bar to log in as Student or Admin.
Internet is needed once for fonts, icons and charts (CDN).

Files: index.html (pages + styles), app.js (logic), mock.js (fake backend), demo.js (login buttons).
To connect the real backend later, use taste-and-bites-backend-connected.zip.
