function demoLogin(e){S.page="login";$("aEmail").value=e;$("aPass").value="demo";signup=false;submitAuth()}
