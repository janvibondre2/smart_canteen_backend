/* Taste & Bites — frontend wired to the Smart Canteen FastAPI backend */
const C = window.TB_CONFIG;
const sb = supabase.createClient(C.SUPABASE_URL, C.SUPABASE_ANON_KEY);
const $ = id => document.getElementById(id), M = n => '₹' + Number(n || 0).toFixed(0);
const FALLBACK = window.TB_FALLBACK;
const ST = ['PLACED', 'CONFIRMED', 'PREPARING', 'READY', 'COMPLETED'], ALL = [...ST, 'CANCELLED'];
const STEP_IC = ['clipboard-check', 'thumbs-up', 'fire-burner', 'bell-concierge', 'flag-checkered'];
const CAT_IC = { meals: 'bowl-rice', snacks: 'burger', beverages: 'mug-hot', desserts: 'cookie', salads: 'carrot', combos: 'pizza-slice' };
let S = { user: null, role: 'student', profile: {}, foods: [], cats: [], cat: 0, q: '', cart: [], notes: [], sel: null, page: 'home' };
let charts = {}, signup = false;

async function api(method, path, params) {
  const qs = params ? '?' + new URLSearchParams(params) : '';
  const r = await fetch(C.API_URL + path + qs, { method });
  if (!r.ok) throw new Error(r.status);
  return r.json();
}
function showToast(msg) {
  $('toastMsg').textContent = msg; $('toast').classList.add('show');
  clearTimeout(window._tt); window._tt = setTimeout(() => $('toast').classList.remove('show'), 2800);
}
const when = d => d ? new Date(d).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }) : '—';
const pill = s => `<span style="padding:3px 10px;border-radius:99px;font-size:11px;font-weight:700;background:${s === 'CANCELLED' ? '#FBE0DC;color:#B3261E' : s === 'COMPLETED' || s === 'READY' ? '#E5F3E6;color:#1B5E20' : '#FFE7D6;color:#C25A1A'}">${s}</span>`;
const guard = () => { if (!S.user) { showToast('Please log in first'); goTo('login'); return false } return true };

/* ---------- Router ---------- */
function goTo(page) {
  if (['cart', 'dashboard', 'tracking', 'profile'].includes(page) && !guard()) return;
  if (page === 'admin' && S.role !== 'admin') { showToast('Admin access required'); return }
  S.page = page;
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  $('page-' + page).classList.add('active');
  window.scrollTo({ top: 0, behavior: 'smooth' }); $('navLinks').classList.remove('open');
  ({ cart: loadCart, dashboard: loadDash, tracking: loadOrders, admin: loadAdmin, profile: renderProfile, contact: loadFbOrders })[page]?.();
  renderNav();
}
function toggleMobileNav() { $('navLinks').classList.toggle('open') }
function renderNav() {
  const l = [['home', 'Home'], ['menu', 'Menu'], ['tracking', 'Orders'], ['contact', 'Contact'], ['about', 'About']];
  if (S.role === 'admin') l.push(['admin', 'Admin']);
  $('navLinks').innerHTML = l.map(([k, t]) => `<a href="#" class="${S.page === k ? 'active' : ''}" onclick="event.preventDefault();goTo('${k}')">${t}</a>`).join('');
  const n = S.cart.reduce((a, i) => a + i.quantity, 0), u = S.notes.filter(x => !x.is_read).length;
  $('cartBadge').textContent = n; $('cartBadge').style.display = n ? 'flex' : 'none';
  $('bellBadge').textContent = u; $('bellBadge').style.display = u ? 'flex' : 'none';
  $('authBtn').textContent = S.user ? 'Log Out' : 'Login'; $('authBtn').onclick = () => S.user ? logout() : goTo('login');
}

/* ---------- Auth (Supabase) ---------- */
function toggleAuth(e) {
  e && e.preventDefault(); signup = !signup;
  $('authTitle').textContent = signup ? 'Create your account' : 'Welcome back';
  $('authSubmit').textContent = signup ? 'Sign Up' : 'Log In';
  $('switchLine').innerHTML = signup ? 'Already have an account? <a href="#" onclick="toggleAuth(event)">Log in</a>' : 'New here? <a href="#" onclick="toggleAuth(event)">Create an account</a>';
}
async function submitAuth() {
  const email = $('aEmail').value.trim(), password = $('aPass').value;
  if (!email || !password) return showToast('Enter email and password');
  const { data, error } = signup ? await sb.auth.signUp({ email, password }) : await sb.auth.signInWithPassword({ email, password });
  if (error) return showToast(error.message);
  if (signup && !data.session) { showToast('Account created — confirm your email, then log in.'); toggleAuth(); }
}
async function logout() { await sb.auth.signOut(); goTo('home') }
sb.auth.onAuthStateChange((_, s) => setSession(s));
async function setSession(s) {
  S.user = s?.user || null;
  if (S.user) {
    try { S.profile = await api('GET', '/profile/' + S.user.id) } catch { S.profile = {} }
    S.role = S.profile.role || 'student';
    await Promise.all([loadCart(true), loadNotes()]);
    if (S.page === 'login') { showToast('Welcome to Taste & Bites!'); goTo(S.role === 'admin' ? 'admin' : 'dashboard') }
  } else { S.cart = []; S.notes = []; S.role = 'student'; S.profile = {} }
  renderNav();
}
const nameOf = () => S.profile.name || (S.user?.email || 'there').split('@')[0];

/* ---------- Menu ---------- */
async function loadMenu() {
  try { [S.foods, S.cats] = await Promise.all([api('GET', '/food-items'), api('GET', '/categories')]) }
  catch { showToast('Cannot reach the server — is the backend running?'); return }
  $('hsDishes').textContent = S.foods.length; $('hsCats').textContent = S.cats.length;
  $('homeCats').innerHTML = S.cats.map(c => `<div class="cat-chip" onclick="S.cat=${c.id};renderMenu();goTo('menu')"><div class="ic"><i class="fa-solid fa-${CAT_IC[c.name.toLowerCase()] || 'utensils'}"></i></div><b>${c.name}</b><span>${S.foods.filter(f => f.category_id === c.id).length} items</span></div>`).join('');
  renderMenu(); $('homeFoodGrid').innerHTML = S.foods.slice(0, 4).map(foodCard).join('');
}
function renderMenu() {
  $('menuPills').innerHTML = [{ id: 0, name: 'All' }, ...S.cats].map(c => `<button class="filter-pill ${S.cat === c.id ? 'active' : ''}" onclick="S.cat=${c.id};renderMenu()">${c.name}</button>`).join('');
  const l = S.foods.filter(f => (!S.cat || f.category_id === S.cat) && f.name.toLowerCase().includes(S.q.toLowerCase()));
  $('menuFoodGrid').innerHTML = l.map(foodCard).join('') || '<p style="color:var(--ink-soft)">No dishes found.</p>';
}
function foodCard(f) {
  const cat = S.cats.find(c => c.id === f.category_id)?.name || 'Canteen', low = f.stock_quantity != null && f.stock_quantity <= 5;
  return `<div class="food-card"><div class="imgwrap"><img src="${f.image_url || FALLBACK}" alt="${f.name}" onerror="this.src='${FALLBACK}'">
  <span class="veg-dot" style="color:${f.available ? (low ? '#C25A1A' : '#1B5E20') : '#B3261E'}">${f.available ? (low ? 'ONLY ' + f.stock_quantity + ' LEFT' : 'AVAILABLE') : 'SOLD OUT'}</span></div>
  <div class="food-body"><div class="rating"><i class="fa-solid fa-tag"></i> ${cat}</div><h4>${f.name}</h4><div class="desc">${f.description || ''}</div>
  <div class="food-foot"><span class="price">${M(f.price)}</span><button class="add-btn" ${f.available ? '' : 'disabled style="opacity:.4;cursor:not-allowed"'} onclick="addToCart(${f.id})"><i class="fa-solid fa-plus"></i></button></div></div></div>`;
}

/* ---------- Cart / checkout ---------- */
async function loadCart(quiet) {
  if (!S.user) return;
  try { S.cart = (await api('GET', '/cart/' + S.user.id)).items || [] } catch { if (!quiet) showToast('Could not load cart') }
  renderCart(); renderNav();
}
async function addToCart(id) {
  if (!guard()) return;
  const f = S.foods.find(x => x.id === id), ex = S.cart.find(i => i.food_item_id === id);
  try {
    ex ? await api('PUT', '/cart/items/' + ex.id, { quantity: ex.quantity + 1 }) : await api('POST', `/cart/${S.user.id}/items`, { food_item_id: id, quantity: 1 });
    await loadCart(); showToast(f.name + ' added to cart');
  } catch { showToast('Could not add item') }
}
async function changeQty(itemId, q) {
  try { q < 1 ? await api('DELETE', '/cart/items/' + itemId) : await api('PUT', '/cart/items/' + itemId, { quantity: q }); loadCart() } catch { showToast('Update failed') }
}
function renderCart() {
  const f = id => S.foods.find(x => x.id === id) || {}, total = S.cart.reduce((a, i) => a + (f(i.food_item_id).price || 0) * i.quantity, 0);
  $('cartItems').innerHTML = S.cart.map(i => { const d = f(i.food_item_id); return `<div class="cart-item"><img src="${d.image_url || FALLBACK}" onerror="this.src='${FALLBACK}'"><div class="info"><h4>${d.name || 'Item'}</h4><span>${M(d.price)} each</span></div>
  <div class="qty-ctrl"><button onclick="changeQty(${i.id},${i.quantity - 1})">−</button><span>${i.quantity}</span><button onclick="changeQty(${i.id},${i.quantity + 1})">+</button></div>
  <div class="cprice">${M(d.price * i.quantity)}</div><i class="fa-solid fa-trash remove-x" onclick="changeQty(${i.id},0)"></i></div>` }).join('')
    || '<div class="panel" style="text-align:center"><h3>Your cart is empty</h3><button class="btn btn-primary" onclick="goTo(\'menu\')">Browse menu</button></div>';
  $('cartCount').textContent = S.cart.reduce((a, i) => a + i.quantity, 0) + ' items'; $('cartSub').textContent = $('cartTotal').textContent = M(total);
}
async function placeOrder() {
  if (!S.cart.length) return showToast('Your cart is empty');
  const pt = $('pickup').value; if (!pt) return showToast('Choose a pickup time');
  $('placeBtn').disabled = true;
  try {
    const o = await api('POST', '/checkout/' + S.user.id, { pickup_time: new Date(pt).toISOString() });
    if (!o.order_id) return showToast(o.message || 'Checkout failed');
    await api('POST', '/payment/' + o.order_id);
    const inv = await api('POST', '/inventory/reduce/' + o.order_id);
    showToast(inv.message?.startsWith('Inventory') ? `Order #${o.order_id} placed & paid!` : `Order #${o.order_id} placed. ${inv.message}`);
    S.sel = o.order_id; S.cart = []; loadMenu(); loadNotes(); goTo('tracking');
  } catch { showToast('Checkout failed') } finally { $('placeBtn').disabled = false }
}

/* ---------- Orders & tracking ---------- */
async function loadOrders() {
  let orders = []; try { orders = await api('GET', '/my-orders/' + S.user.id) } catch { showToast('Could not load orders') }
  if (!orders.find(o => o.id === S.sel)) S.sel = orders[0]?.id;
  $('orderPicker').innerHTML = orders.map(o => `<button class="filter-pill ${o.id === S.sel ? 'active' : ''}" onclick="S.sel=${o.id};loadOrders()">#${o.id}</button>`).join('');
  const o = orders.find(x => x.id === S.sel);
  if (!o) { $('trTag').textContent = 'No orders'; $('trTitle').textContent = 'Nothing here yet'; $('trSub').textContent = ''; $('trackPanel').innerHTML = '<p>Place your first order from the menu.</p>'; $('trackItems').innerHTML = ''; return }
  $('trTag').textContent = 'Order #' + o.id; $('trTitle').textContent = o.order_status === 'CANCELLED' ? 'This order was cancelled' : o.order_status === 'COMPLETED' ? 'Enjoy your meal!' : 'Your order is in progress';
  $('trSub').innerHTML = `Pickup: <strong style="color:var(--green-900)">${when(o.pickup_time)}</strong> · Payment ${o.payment_status}`;
  const k = ST.indexOf(o.order_status);
  $('trackPanel').innerHTML = o.order_status === 'CANCELLED' ? '<p style="margin:0">This order has been cancelled.</p>' : `<div class="timeline">${ST.map((s, i) => `<div class="tl-step ${i <= k ? 'active' : 'pending'}"><div class="tl-dot"><i class="fa-solid fa-${STEP_IC[i]}"></i></div><h4>${s[0] + s.slice(1).toLowerCase()}</h4><span>${i === k ? 'Current status' : i < k ? 'Done' : 'Upcoming'}</span></div>`).join('')}</div>`;
  let items = []; try { items = (await api('GET', `/orders/${o.id}/details`)).items || [] } catch { }
  $('trackItems').innerHTML = items.map(i => `<div class="order-row"><img src="${i.food_items?.image_url || FALLBACK}" onerror="this.src='${FALLBACK}'"><div class="oi"><b>${i.food_items?.name || 'Item'} × ${i.quantity}</b><span>${M(i.price)} each</span></div><b>${M(i.price * i.quantity)}</b></div>`).join('')
    + `<div style="display:flex;justify-content:space-between;align-items:center;margin-top:14px;flex-wrap:wrap;gap:10px"><b style="font-size:18px">Total ${M(o.total_amount)}</b><span>${o.order_status === 'PLACED' ? `<button class="btn btn-ghost btn-sm" onclick="cancelOrder(${o.id})">Cancel order</button>` : ''}${o.order_status === 'COMPLETED' ? `<button class="btn btn-orange btn-sm" onclick="goTo('contact')">Rate this order</button>` : ''}</span></div>`;
}
async function cancelOrder(id) {
  try { const r = await api('POST', `/orders/${id}/cancel`, { user_id: S.user.id }); showToast(r.message); loadOrders(); loadNotes() } catch { showToast('Could not cancel') }
}

/* ---------- Notifications, dashboard ---------- */
async function loadNotes() { if (!S.user) return; try { S.notes = await api('GET', '/notifications/' + S.user.id) } catch { } renderNav() }
async function readNote(id) { await api('PUT', `/notifications/${id}/read`); await loadNotes(); renderNotes() }
function renderNotes() {
  $('sUnread').textContent = S.notes.filter(n => !n.is_read).length;
  $('notifList').innerHTML = S.notes.slice(0, 8).map(n => `<div class="order-row"><div class="ic" style="width:40px;height:40px;border-radius:12px;background:${n.is_read ? '#F1EEE3' : '#FFE7D6'};display:flex;align-items:center;justify-content:center"><i class="fa-solid fa-bell"></i></div><div class="oi"><b>${n.message}</b><span>${when(n.created_at)}</span></div>${n.is_read ? '' : `<button class="btn btn-ghost btn-sm" onclick="readNote(${n.id})">Mark read</button>`}</div>`).join('') || '<p style="color:var(--ink-soft)">No notifications yet.</p>';
}
const lastDays = () => [...Array(7)].map((_, i) => { const d = new Date(); d.setDate(d.getDate() - 6 + i); return d.toISOString().slice(0, 10) });
function mkChart(id, cfg) { charts[id]?.destroy(); charts[id] = new Chart($(id), cfg) }
async function loadDash() {
  $('dName').textContent = nameOf(); $('dAvatar').textContent = nameOf()[0].toUpperCase(); $('dRole').textContent = S.role; $('dHello').textContent = `Hello, ${nameOf()} 👋`;
  let orders = [], fbs = []; try { [orders, fbs] = await Promise.all([api('GET', '/my-orders/' + S.user.id), api('GET', '/feedback/user/' + S.user.id), loadNotes()]) } catch { }
  const ok = orders.filter(o => o.order_status !== 'CANCELLED');
  $('sOrders').textContent = orders.length; $('sSpent').textContent = M(ok.reduce((a, o) => a + Number(o.total_amount), 0));
  $('sRating').textContent = fbs.length ? (fbs.reduce((a, f) => a + f.rating, 0) / fbs.length).toFixed(1) : '–';
  $('recentOrders').innerHTML = orders.slice(0, 5).map(o => `<div class="order-row"><div class="ic" style="width:44px;height:44px;border-radius:12px;background:var(--green-100);color:var(--green-900);display:flex;align-items:center;justify-content:center"><i class="fa-solid fa-receipt"></i></div><div class="oi"><b>Order #${o.id}</b><span>${when(o.created_at)}</span></div><div style="text-align:right">${pill(o.order_status)}<div><b>${M(o.total_amount)}</b></div></div></div>`).join('') || '<p style="color:var(--ink-soft)">No orders yet.</p>';
  renderNotes();
  const days = lastDays();
  mkChart('userSpendChart', { type: 'line', data: { labels: days.map(d => d.slice(5)), datasets: [{ label: 'Spend (₹)', data: days.map(d => ok.filter(o => (o.created_at || '').slice(0, 10) === d).reduce((a, o) => a + Number(o.total_amount), 0)), borderColor: '#2E7D32', backgroundColor: 'rgba(46,125,50,0.12)', fill: true, tension: .4 }] }, options: { plugins: { legend: { display: false } }, scales: { x: { grid: { display: false } } } } });
}

/* ---------- Profile & feedback ---------- */
function renderProfile() {
  $('pName').value = S.profile.name || ''; $('pPhone').value = S.profile.phone || ''; $('pMail').value = S.user.email; $('pRole').value = S.role;
  $('pTitle').textContent = nameOf(); $('pEmail').textContent = S.user.email; $('pAvatar').textContent = nameOf()[0].toUpperCase();
}
async function saveProfile() {
  try { const r = await api('PUT', '/profile/' + S.user.id, { name: $('pName').value, phone: $('pPhone').value }); if (r.profile) S.profile = r.profile; showToast(r.message); renderProfile() } catch { showToast('Update failed') }
}
async function loadFbOrders() {
  if (!S.user) { $('fbOrder').innerHTML = '<option>Log in to leave feedback</option>'; return }
  try {
    const [o, f] = await Promise.all([api('GET', '/my-orders/' + S.user.id), api('GET', '/feedback/user/' + S.user.id)]), done = new Set(f.map(x => x.order_id));
    const l = o.filter(x => x.order_status === 'COMPLETED' && !done.has(x.id));
    $('fbOrder').innerHTML = l.map(x => `<option value="${x.id}">Order #${x.id} — ${M(x.total_amount)}</option>`).join('') || '<option value="">No completed orders to review</option>';
  } catch { }
}
async function sendFeedback() {
  if (!guard()) return; const id = $('fbOrder').value; if (!id) return showToast('No completed order to review');
  try { const r = await api('POST', `/feedback/${S.user.id}/${id}`, { rating: $('fbRating').value, comment: $('fbComment').value }); showToast(r.message); $('fbComment').value = ''; loadFbOrders() } catch { showToast('Could not send feedback') }
}

/* ---------- Admin ---------- */
async function loadAdmin() {
  $('aName').textContent = nameOf();
  let d; try { d = await Promise.all([api('GET', '/orders'), api('GET', '/admin/analytics/sales'), api('GET', '/admin/analytics/orders'), api('GET', '/admin/analytics/inventory'), api('GET', '/admin/feedback')]) } catch { return showToast('Could not load admin data') }
  const [orders, sales, os, inv, fb] = d, by = os.orders_by_status, active = ['PLACED', 'CONFIRMED', 'PREPARING', 'READY'].reduce((a, k) => a + by[k], 0);
  const card = (ic, c, v, l) => `<div class="stat-card"><div class="top"><div class="ic ${c}"><i class="fa-solid fa-${ic}"></i></div></div><b>${v}</b><span class="label">${l}</span></div>`;
  $('adStats').innerHTML = card('indian-rupee-sign', 'g', M(sales.total_sales), 'Total sales') + card('receipt', 'o', os.total_orders, 'Total orders') + card('fire-burner', 'g', active, 'Active orders') + card('star', 'o', fb.average_rating + ' ★', `${fb.total_feedback} reviews`);
  const days = lastDays(), ok = orders.filter(o => o.payment_status === 'SUCCESS' && o.order_status !== 'CANCELLED');
  mkChart('adminRevenueChart', { type: 'bar', data: { labels: days.map(x => x.slice(5)), datasets: [{ label: 'Revenue (₹)', data: days.map(x => ok.filter(o => (o.created_at || '').slice(0, 10) === x).reduce((a, o) => a + Number(o.total_amount), 0)), backgroundColor: '#2E7D32', borderRadius: 8, maxBarThickness: 34 }] }, options: { plugins: { legend: { display: false } }, scales: { x: { grid: { display: false } } } } });
  mkChart('adminCategoryChart', { type: 'doughnut', data: { labels: ALL, datasets: [{ data: ALL.map(k => by[k]), backgroundColor: ['#2E7D32', '#43A047', '#FF8A4C', '#F5B84C', '#8BC98F', '#C1462F'], borderWidth: 0 }] }, options: { plugins: { legend: { position: 'bottom', labels: { boxWidth: 10, font: { size: 11 } } } }, cutout: '65%' } });
  $('queue').innerHTML = orders.slice(0, 12).map(o => `<div class="order-row"><div class="ic" style="width:44px;height:44px;border-radius:12px;background:var(--green-100);color:var(--green-900);display:flex;align-items:center;justify-content:center"><i class="fa-solid fa-receipt"></i></div><div class="oi"><b>#${o.id} · ${M(o.total_amount)}</b><span>Pickup ${when(o.pickup_time)} · ${o.payment_status}</span></div>
    <select onchange="setStatus(${o.id},this.value)" style="padding:8px 12px;border-radius:99px;border:1px solid var(--line);font:inherit">${ALL.map(s => `<option ${s === o.order_status ? 'selected' : ''}>${s}</option>`).join('')}</select></div>`).join('') || '<p>No orders yet.</p>';
  $('inv').innerHTML = inv.map(i => `<div class="order-row"><div class="oi"><b>${i.food_items?.name || 'Item #' + i.food_item_id}</b></div><b style="color:${i.quantity <= 5 ? '#C1462F' : 'var(--green-900)'}">${i.quantity} left</b></div>`).join('');
  $('fbList').innerHTML = fb.feedback.slice(0, 8).map(f => `<div class="order-row"><div class="oi"><b style="color:#F5B84C">${'★'.repeat(f.rating)}</b><span>“${f.comment || '—'}” · order #${f.order_id}</span></div></div>`).join('') || '<p>No feedback yet.</p>';
}
async function setStatus(id, s) { try { await api('PUT', `/admin/orders/${id}/status`, { status: s }); showToast(`Order #${id} → ${s}`); loadAdmin() } catch { showToast('Update failed') } }

/* ---------- Init ---------- */
$('menuSearch')?.addEventListener('input', e => { S.q = e.target.value; renderMenu() });
loadMenu(); renderNav();
sb.auth.getSession().then(({ data }) => setSession(data.session));
