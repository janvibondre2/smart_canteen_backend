import React, { useEffect, useMemo, useRef, useState } from 'react';

class TaskNode {
  constructor(task) {
    this.task = task;
    this.next = null;
  }
}

class TaskLinkedList {
  constructor() {
    this.head = null;
  }

  append(task) {
    const node = new TaskNode(task);
    if (!this.head) {
      this.head = node;
      return;
    }
    let current = this.head;
    while (current.next) {
      current = current.next;
    }
    current.next = node;
  }

  toArray() {
    const list = [];
    let current = this.head;
    while (current) {
      list.push(current.task);
      current = current.next;
    }
    return list;
  }
}

const initialTasks = [
  { id: 1, title: 'Buy groceries', priority: 'High', deadline: '2026-08-10', time: '17:00', completed: false },
  { id: 2, title: 'Plan meeting agenda', priority: 'Medium', deadline: '2026-08-12', time: '09:30', completed: false },
  { id: 3, title: 'Review project notes', priority: 'Low', deadline: '2026-08-15', time: '14:00', completed: false },
];

const priorityOrder = {
  High: 1,
  Medium: 2,
  Low: 3,
};

function App() {
  const [tasks, setTasks] = useState(initialTasks);
  const [pendingQueue, setPendingQueue] = useState(initialTasks.filter((task) => !task.completed));
  const [undoStack, setUndoStack] = useState([]);
  const [title, setTitle] = useState('');
  const [priority, setPriority] = useState('Medium');
  const [deadline, setDeadline] = useState('');
  const [time, setTime] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortByPriority, setSortByPriority] = useState(false);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const notifiedTaskIdsRef = useRef(new Set());

  const linkedList = useMemo(() => {
    const list = new TaskLinkedList();
    tasks.forEach((task) => list.append(task));
    return list;
  }, [tasks]);

  const filteredTasks = useMemo(() => {
    let result = [...tasks];
    if (searchQuery.trim()) {
      result = result.filter((task) =>
        task.title.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    if (sortByPriority) {
      result.sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]);
    }
    return result;
  }, [tasks, searchQuery, sortByPriority]);

  const upcomingDeadlines = useMemo(() => {
    return [...tasks]
      .filter((task) => !task.completed && task.deadline)
      .sort((a, b) => {
        if (a.deadline === b.deadline) {
          return a.time.localeCompare(b.time);
        }
        return a.deadline.localeCompare(b.deadline);
      });
  }, [tasks]);

  useEffect(() => {
    if (!notificationsEnabled) {
      return;
    }

    const alarm = setInterval(() => {
      const now = new Date();
      tasks.forEach((task) => {
        if (task.completed || !task.deadline || !task.time) return;

        const deadlineDate = new Date(`${task.deadline}T${task.time}`);
        if (now >= deadlineDate && !notifiedTaskIdsRef.current.has(task.id)) {
          notifiedTaskIdsRef.current.add(task.id);
          const message = `Deadline reached: ${task.title} is due now (${task.deadline} ${task.time}).`;
          window.alert(message);
        }
      });
    }, 30 * 1000);

    return () => clearInterval(alarm);
  }, [tasks, notificationsEnabled]);

  const addTask = () => {
    if (!title.trim() || !deadline || !time) return;
    const nextId = Math.max(0, ...tasks.map((task) => task.id)) + 1;
    const newTask = { id: nextId, title: title.trim(), priority, deadline, time, completed: false };
    setTasks((prev) => [...prev, newTask]);
    setPendingQueue((prev) => [...prev, newTask]);
    setTitle('');
    setPriority('Medium');
    setDeadline('');
    setTime('');
  };

  const deleteTask = (id) => {
    const deletedTask = tasks.find((task) => task.id === id);
    if (!deletedTask) return;
    setTasks((prev) => prev.filter((task) => task.id !== id));
    setPendingQueue((prev) => prev.filter((task) => task.id !== id));
    setUndoStack((prev) => [...prev, deletedTask]);
  };

  const markCompleted = (id) => {
    setTasks((prev) =>
      prev.map((task) =>
        task.id === id ? { ...task, completed: true } : task
      )
    );
    setPendingQueue((prev) => prev.filter((task) => task.id !== id));
  };

  const undoDelete = () => {
    const lastDeleted = undoStack[undoStack.length - 1];
    if (!lastDeleted) return;
    setUndoStack((prev) => prev.slice(0, -1));
    setTasks((prev) => [...prev, lastDeleted]);
    if (!lastDeleted.completed) {
      setPendingQueue((prev) => [...prev, lastDeleted]);
    }
  };

  const notifyTask = (task) => {
    const message = `Reminder: "${task.title}" is due on ${task.deadline} at ${task.time}.`;
    window.alert(message);
  };

  const clearSearch = () => setSearchQuery('');

  return (
    <div className="app-shell">
      <header>
        <h1>Smart Task Manager</h1>
        <p>DSA: Linked List, Stack, Queue, Arrays</p>
      </header>

      <section className="task-form">
        <div className="task-inputs">
          <input
            value={title}
            onChange={(event) => setTitle(event.target.value)}
            placeholder="Task title"
          />
          <select value={priority} onChange={(event) => setPriority(event.target.value)}>
            <option>High</option>
            <option>Medium</option>
            <option>Low</option>
          </select>
          <input
            type="date"
            value={deadline}
            onChange={(event) => setDeadline(event.target.value)}
          />
          <input
            type="time"
            value={time}
            onChange={(event) => setTime(event.target.value)}
          />
          <button onClick={addTask}>Add task</button>
        </div>

        <div className="search-row">
          <input
            value={searchQuery}
            onChange={(event) => setSearchQuery(event.target.value)}
            placeholder="Search tasks"
          />
          <button onClick={clearSearch}>Clear</button>
          <label>
            <input
              type="checkbox"
              checked={sortByPriority}
              onChange={(event) => setSortByPriority(event.target.checked)}
            />
            Sort by priority
          </label>
          <label>
            <input
              type="checkbox"
              checked={notificationsEnabled}
              onChange={(event) => setNotificationsEnabled(event.target.checked)}
            />
            Enable deadline notifications
          </label>
        </div>
      </section>

      <main className="grid">
        <section className="panel">
          <h2>Task list</h2>
          <div className="task-list">
            {filteredTasks.length === 0 ? (
              <div className="empty-state">No tasks found</div>
            ) : (
              filteredTasks.map((task) => (
                <div key={task.id} className={`task-card ${task.completed ? 'completed' : ''}`}>
                  <div className="task-main">
                    <div className="task-heading">
                      <strong>{task.title}</strong>
                      <span className={`tag ${task.priority.toLowerCase()}`}>{task.priority}</span>
                    </div>
                    <div className="task-meta">
                      <span>{task.deadline}</span>
                      <span>{task.time}</span>
                    </div>
                  </div>
                  <div className="task-actions">
                    {!task.completed && (
                      <button onClick={() => markCompleted(task.id)}>Complete</button>
                    )}
                    <button onClick={() => notifyTask(task)}>Notify</button>
                    <button onClick={() => deleteTask(task.id)}>Delete</button>
                  </div>
                </div>
              ))
            )}
          </div>
        </section>

        <section className="panel">
          <h2>Undo stack</h2>
          <div className="small-panel">
            <button onClick={undoDelete} disabled={undoStack.length === 0}>
              Undo last delete
            </button>
            <p>Deleted tasks stored in stack order (last deleted is first restored).</p>
            <ol>
              {undoStack.slice().reverse().map((task) => (
                <li key={task.id}>{task.title}</li>
              ))}
            </ol>
          </div>

          <h2>Pending task queue</h2>
          <div className="small-panel">
            <p>First-in first-out queue for pending work.</p>
            <ol>
              {pendingQueue.map((task) => (
                <li key={task.id}>{task.title}</li>
              ))}
            </ol>
          </div>

          <h2>Upcoming deadlines</h2>
          <div className="small-panel">
            <p>Pending tasks sorted by deadline and time.</p>
            <ol>
              {upcomingDeadlines.map((task) => (
                <li key={task.id}>
                  {task.deadline} {task.time} – {task.title}
                </li>
              ))}
            </ol>
          </div>

          <h2>Linked list preview</h2>
          <div className="small-panel">
            <p>Task order represented as a singly linked list:</p>
            <div className="linked-list">
              {linkedList.toArray().map((task, index, array) => (
                <span key={task.id}>
                  {task.title}
                  {index < array.length - 1 && <span className="arrow">→</span>}
                </span>
              ))}
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

export default App;
