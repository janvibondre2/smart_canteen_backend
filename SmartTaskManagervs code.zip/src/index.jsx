const { useEffect, useMemo, useRef, useState } = React;

class TaskNode {
  constructor(task) {
    this.task = task;
    this.next = null;
  }
}

class TaskLinkedList {
  constructor() {
    this.head = null;
  }

  append(task) {
    const node = new TaskNode(task);
    if (!this.head) {
      this.head = node;
      return;
    }
    let current = this.head;
    while (current.next) {
      current = current.next;
    }
    current.next = node;
  }

  toArray() {
    const list = [];
    let current = this.head;
    while (current) {
      list.push(current.task);
      current = current.next;
    }
    return list;
  }
}

const initialTasks = [
  { id: 1, title: 'Buy groceries', priority: 'High', deadline: '2026-08-10', time: '17:00', completed: false },
  { id: 2, title: 'Plan meeting agenda', priority: 'Medium', deadline: '2026-08-12', time: '09:30', completed: false },
  { id: 3, title: 'Review project notes', priority: 'Low', deadline: '2026-08-15', time: '14:00', completed: false },
];

const priorityOrder = {
  High: 1,
  Medium: 2,
  Low: 3,
};

function App() {
  const [tasks, setTasks] = useState(initialTasks);
  const [pendingQueue, setPendingQueue] = useState(initialTasks.filter((task) => !task.completed));
  const [undoStack, setUndoStack] = useState([]);
  const [title, setTitle] = useState('');
  const [priority, setPriority] = useState('Medium');
  const [deadline, setDeadline] = useState('');
  const [time, setTime] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortByPriority, setSortByPriority] = useState(false);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [assistantInput, setAssistantInput] = useState('');
  const [assistantMessages, setAssistantMessages] = useState([
    { role: 'assistant', text: 'Good morning. I can help you find priorities, deadlines, and the next task to tackle.' },
  ]);
  const notifiedTaskIdsRef = useRef(new Set());

  const linkedList = useMemo(() => {
    const list = new TaskLinkedList();
    tasks.forEach((task) => list.append(task));
    return list;
  }, [tasks]);

  const totalTasks = tasks.length;
  const completedCount = tasks.filter((task) => task.completed).length;
  const pendingCount = tasks.filter((task) => !task.completed).length;
  const overdueCount = tasks.filter((task) => {
    if (task.completed || !task.deadline || !task.time) return false;
    return new Date(`${task.deadline}T${task.time}`) < new Date();
  }).length;

  const filteredTasks = useMemo(() => {
    let result = [...tasks];
    if (searchQuery.trim()) {
      result = result.filter((task) =>
        task.title.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    if (sortByPriority) {
      result.sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]);
    }
    return result;
  }, [tasks, searchQuery, sortByPriority]);

  useEffect(() => {
    if (!notificationsEnabled) return;

    const interval = setInterval(() => {
      const now = new Date();
      setCurrentTime(now);
      tasks.forEach((task) => {
        if (task.completed || !task.deadline || !task.time) return;
        const deadlineDate = new Date(`${task.deadline}T${task.time}`);
        if (now >= deadlineDate && !notifiedTaskIdsRef.current.has(task.id)) {
          notifiedTaskIdsRef.current.add(task.id);
          window.alert(`Deadline reached: ${task.title} is due now (${task.deadline} ${task.time}).`);
        }
      });
    }, 30 * 1000);

    return () => clearInterval(interval);
  }, [tasks, notificationsEnabled]);

  const addTask = () => {
    if (!title.trim() || !deadline || !time) return;
    const nextId = Math.max(0, ...tasks.map((task) => task.id)) + 1;
    const newTask = { id: nextId, title: title.trim(), priority, deadline, time, completed: false };
    setTasks((prev) => [...prev, newTask]);
    setPendingQueue((prev) => [...prev, newTask]);
    setTitle('');
    setPriority('Medium');
    setDeadline('');
    setTime('');
  };

  const getDeadlineStatus = (task) => {
    if (task.completed) return 'Completed';
    if (!task.deadline || !task.time) return 'No deadline';
    const diff = new Date(`${task.deadline}T${task.time}`) - currentTime;
    if (diff < 0) return 'Overdue';
    if (diff <= 60 * 60 * 1000) return 'Due soon';
    if (diff <= 24 * 60 * 60 * 1000) return 'Due today';
    return 'Upcoming';
  };

  const deleteTask = (id) => {
    const deletedTask = tasks.find((task) => task.id === id);
    if (!deletedTask) return;
    setTasks((prev) => prev.filter((task) => task.id !== id));
    setPendingQueue((prev) => prev.filter((task) => task.id !== id));
    setUndoStack((prev) => [...prev, deletedTask]);
  };

  const markCompleted = (id) => {
    setTasks((prev) =>
      prev.map((task) =>
        task.id === id ? { ...task, completed: true } : task
      )
    );
    setPendingQueue((prev) => prev.filter((task) => task.id !== id));
  };

  const undoDelete = () => {
    const lastDeleted = undoStack[undoStack.length - 1];
    if (!lastDeleted) return;
    setUndoStack((prev) => prev.slice(0, -1));
    setTasks((prev) => [...prev, lastDeleted]);
    if (!lastDeleted.completed) {
      setPendingQueue((prev) => [...prev, lastDeleted]);
    }
  };

  const clearSearch = () => setSearchQuery('');

  const runAssistantPrompt = (prompt) => {
    const normalizedPrompt = prompt.toLowerCase();
    let response = 'I can help with tasks, deadlines, and priorities. Try asking what is due or what to focus on.';

    if (normalizedPrompt.includes('due') || normalizedPrompt.includes('deadline')) {
      response = upcomingDeadlines.length
        ? `You have ${upcomingDeadlines.length} pending deadline${upcomingDeadlines.length === 1 ? '' : 's'}. The next one is ${upcomingDeadlines[0].title} on ${upcomingDeadlines[0].deadline} at ${upcomingDeadlines[0].time}.`
        : 'You have no pending deadlines. Your queue is clear.';
    } else if (normalizedPrompt.includes('focus') || normalizedPrompt.includes('priority') || normalizedPrompt.includes('next')) {
      const nextTask = [...tasks]
        .filter((task) => !task.completed)
        .sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority])[0];
      response = nextTask
        ? `Focus on “${nextTask.title}” next. It is ${nextTask.priority.toLowerCase()} priority and due ${nextTask.deadline} at ${nextTask.time}.`
        : 'Everything is complete. This is a good moment to plan the next task.';
    } else if (normalizedPrompt.includes('completed') || normalizedPrompt.includes('progress')) {
      response = `You have completed ${completedCount} of ${totalTasks} task${totalTasks === 1 ? '' : 's'} and ${pendingCount} remaining.`;
    }

    setAssistantMessages((messages) => [
      ...messages,
      { role: 'user', text: prompt },
      { role: 'assistant', text: response },
    ]);
    setAssistantInput('');
  };

  const submitAssistantPrompt = (event) => {
    event.preventDefault();
    if (assistantInput.trim()) runAssistantPrompt(assistantInput.trim());
  };

  return (
    <div className="app-shell">
      <header>
        <div className="app-header-copy">
          <h1>Smart Task Manager</h1>
          <p>Track tasks, deadlines, and priorities in a polished task dashboard.</p>
        </div>
        <div className="overview-cards">
          <div className="overview-card total">
            <span>Total tasks</span>
            <strong>{totalTasks}</strong>
          </div>
          <div className="overview-card pending">
            <span>Pending</span>
            <strong>{pendingCount}</strong>
          </div>
          <div className="overview-card completed">
            <span>Completed</span>
            <strong>{completedCount}</strong>
          </div>
          <div className="overview-card overdue">
            <span>Overdue</span>
            <strong>{overdueCount}</strong>
          </div>
        </div>
      </header>

      <section className="task-form">
        <div className="task-inputs">
          <input
            value={title}
            onChange={(event) => setTitle(event.target.value)}
            placeholder="New task title"
          />
          <select value={priority} onChange={(event) => setPriority(event.target.value)}>
            <option>High</option>
            <option>Medium</option>
            <option>Low</option>
          </select>
          <input
            type="date"
            value={deadline}
            onChange={(event) => setDeadline(event.target.value)}
            aria-label="Deadline"
          />
          <input
            type="time"
            value={time}
            onChange={(event) => setTime(event.target.value)}
            aria-label="Time"
          />
          <button onClick={addTask}>Add task</button>
        </div>

        <div className="search-row">
          <input
            value={searchQuery}
            onChange={(event) => setSearchQuery(event.target.value)}
            placeholder="Search tasks"
          />
          <button onClick={clearSearch}>Clear</button>
          <label>
            <input
              type="checkbox"
              checked={sortByPriority}
              onChange={(event) => setSortByPriority(event.target.checked)}
            />
            Sort by priority
          </label>
          <label>
            <input
              type="checkbox"
              checked={notificationsEnabled}
              onChange={(event) => setNotificationsEnabled(event.target.checked)}
            />
            Enable deadline notifications
          </label>
        </div>
      </section>

      <main className="grid">
        <section className="panel">
          <h2>Task list</h2>
          <div className="task-list">
            {filteredTasks.length === 0 ? (
              <div className="empty-state">No tasks found</div>
            ) : (
              filteredTasks.map((task) => (
                <div key={task.id} className={`task-card ${task.completed ? 'completed' : ''}`}>
                  <div className="task-main">
                    <div className="task-heading">
                      <strong>{task.title}</strong>
                      <span className={`tag ${task.priority.toLowerCase()}`}>{task.priority}</span>
                    </div>
                    <div className="task-meta-row">
                      <span>{task.deadline} · {task.time}</span>
                      <span className={`deadline-badge ${getDeadlineStatus(task).toLowerCase().replace(/ /g, '-')}`}>
                        {getDeadlineStatus(task)}
                      </span>
                    </div>
                  </div>
                  <div className="task-actions">
                    {!task.completed && (
                      <button className="complete" onClick={() => markCompleted(task.id)}>Complete</button>
                    )}
                    <button className="delete" onClick={() => deleteTask(task.id)}>Delete</button>
                  </div>
                </div>
              ))
            )}
          </div>
        </section>

        <section className="panel assistant-panel">
          <div className="assistant-heading">
            <div>
              <span className="eyebrow">DESKTOP ASSISTANT</span>
              <h2>Work companion</h2>
            </div>
            <span className="assistant-status"><span /> Ready</span>
          </div>
          <div className="assistant-messages" aria-live="polite">
            {assistantMessages.map((message, index) => (
              <div key={`${message.role}-${index}`} className={`assistant-message ${message.role}`}>
                {message.text}
              </div>
            ))}
          </div>
          <div className="assistant-prompts">
            <button onClick={() => runAssistantPrompt('What is due next?')}>What is due next?</button>
            <button onClick={() => runAssistantPrompt('What should I focus on?')}>Pick my focus</button>
          </div>
          <form className="assistant-input" onSubmit={submitAssistantPrompt}>
            <input
              value={assistantInput}
              onChange={(event) => setAssistantInput(event.target.value)}
              placeholder="Ask about your work..."
              aria-label="Ask the desktop assistant"
            />
            <button type="submit" aria-label="Send assistant message">Send</button>
          </form>

          <h2>Undo stack</h2>
          <div className="small-panel">
            <button onClick={undoDelete} disabled={undoStack.length === 0}>
              Undo last delete
            </button>
            <p>Deleted tasks stored in stack order (last deleted is first restored).</p>
            <ol>
              {undoStack.slice().reverse().map((task) => (
                <li key={task.id}>{task.title}</li>
              ))}
            </ol>
          </div>

          <h2>Pending task queue</h2>
          <div className="small-panel">
            <p>First-in first-out queue for pending work.</p>
            <ol>
              {pendingQueue.map((task) => (
                <li key={task.id}>{task.title}</li>
              ))}
            </ol>
          </div>

          <h2>Linked list preview</h2>
          <div className="small-panel">
            <p>Task order represented as a singly linked list:</p>
            <div className="linked-list">
              {linkedList.toArray().map((task, index, array) => (
                <span key={task.id}>
                  {task.title}
                  {index < array.length - 1 && <span className="arrow">→</span>}
                </span>
              ))}
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
