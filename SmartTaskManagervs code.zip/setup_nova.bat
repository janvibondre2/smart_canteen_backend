@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" py -3.13-64 -m venv .venv
if errorlevel 1 (
    echo Python 3.13 64-bit was not found. Install Python 3.11 or later 64-bit, then retry.
    exit /b 1
)
".venv\Scripts\python.exe" -m pip install -r nova\requirements.txt
if errorlevel 1 exit /b 1
if not exist "nova\.env" copy "nova\.env.example" "nova\.env" >nul
echo Nova setup is ready. Run start_nova.bat to launch.