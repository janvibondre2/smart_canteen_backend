# Smart Task Manager and Nova

This workspace contains the Smart Task Manager web UI and a separate native Windows desktop assistant named Nova.

## Run Nova

Run `setup_nova.bat` once, then `start_nova.bat`. See [nova/README.md](nova/README.md) for requirements, configuration, and tests.

## Run the Smart Task Manager web UI

Open `index.html` in a browser, or start the existing `Run Smart Task Manager` VS Code task and browse to `http://localhost:8000`.
