import json
import tempfile
import threading
import unittest
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen
from unittest.mock import patch

from desktop_assistant_modules.local_web import AssistantService, create_server
from desktop_assistant_modules.storage import AppStore


class LocalWebTests(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory()
        self.addCleanup(temporary.cleanup)
        base = Path(temporary.name)
        self.project = base / "project"
        self.project.mkdir()
        self.home = base / "assistant-home"
        env = patch.dict("os.environ", {"AI_ASSISTANT_HOME": str(self.home)})
        env.start()
        self.addCleanup(env.stop)
        self.store = AppStore(self.project)
        self.service = AssistantService(self.store)
        self.server = create_server(self.service, 0)
        self.addCleanup(self.server.server_close)
        self.thread = threading.Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.addCleanup(self.server.shutdown)
        self.base_url = f"http://127.0.0.1:{self.server.server_port}"

    def test_local_page_and_status_are_available(self):
        with urlopen(self.base_url + "/", timeout=2) as response:
            self.assertEqual(response.status, 200)
            self.assertIn(b"Local AI Computer Assistant", response.read())
        with urlopen(self.base_url + "/api/status", timeout=2) as response:
            status = json.loads(response.read())
        self.assertEqual(status["workspace"], str(self.project.resolve()))
        self.assertEqual(status["preferred_browser"], "chrome")

    def test_untrusted_host_header_is_rejected(self):
        request = Request(self.base_url + "/api/status", headers={"Host": "attacker.example"})
        with self.assertRaises(HTTPError) as error:
            urlopen(request, timeout=2)
        self.assertEqual(error.exception.code, 403)

    def test_browser_confirmation_can_cancel_python_execution(self):
        script = self.store.python_projects_dir() / "test.py"
        script.write_text("print('must not run')", encoding="utf-8")
        request = Request(
            self.base_url + "/api/command",
            data=json.dumps({"command": "Run test.py"}).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urlopen(request, timeout=2) as response:
            self.assertEqual(response.status, 202)

        confirmation = None
        for _ in range(100):
            confirmation = self.service.snapshot()["confirmation"]
            if confirmation:
                break
            threading.Event().wait(0.02)
        self.assertIsNotNone(confirmation)
        self.assertTrue(self.service.confirm(confirmation["id"], False))
        for _ in range(100):
            if not self.service.snapshot()["busy"]:
                break
            threading.Event().wait(0.02)
        self.assertFalse(self.service.snapshot()["busy"])
        self.assertEqual(self.service.snapshot()["messages"][-1]["text"], "Python execution was cancelled.")

    def test_ollama_settings_cannot_point_to_a_remote_host(self):
        with self.assertRaises(ValueError):
            self.service.save_settings({"ollama_base_url": "https://example.com"})


if __name__ == "__main__":
    unittest.main()