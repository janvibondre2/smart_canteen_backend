import unittest

from desktop_assistant_modules.command_planner import plan_command


class CommandPlannerTests(unittest.TestCase):
    def test_google_search_becomes_direct_url(self):
        plan = plan_command("Search Google for cybersecurity internships")
        self.assertEqual(plan.actions[0].kind, "OPEN_URL")
        self.assertEqual(
            plan.actions[0].parameters["url"],
            "https://www.google.com/search?q=cybersecurity+internships",
        )

    def test_youtube_search(self):
        plan = plan_command("Search YouTube for PyTorch tutorials")
        self.assertIn("youtube.com/results?search_query=PyTorch+tutorials", plan.actions[0].parameters["url"])

    def test_application_and_chained_search(self):
        plan = plan_command("Open Chrome and search Google for Cisco cybersecurity internships")
        self.assertEqual([action.kind for action in plan.actions], ["OPEN_APPLICATION", "OPEN_URL"])
        self.assertEqual(plan.actions[0].parameters["application"], "chrome")

    def test_comma_separated_chrome_search_and_youtube_workflow(self):
        plan = plan_command("Open Chrome, search Google for Cisco cybersecurity internships, and open results")
        self.assertEqual([action.kind for action in plan.actions], ["OPEN_APPLICATION", "OPEN_URL"])
        youtube = plan_command("Open YouTube and play PyTorch tutorials")
        self.assertIn("youtube.com/results?search_query=PyTorch+tutorials", youtube.actions[0].parameters["url"])

    def test_application_shortcuts_and_meetings(self):
        tools = plan_command("Open all my development tools")
        self.assertEqual([action.parameters["application"] for action in tools.actions], ["vscode", "terminal", "explorer"])
        meetings = plan_command("Open Teams and check my meetings")
        self.assertEqual([action.kind for action in meetings.actions], ["OPEN_APPLICATION", "OPEN_URL"])
        self.assertEqual(plan_command("Close Chrome").actions[0].parameters["application"], "chrome")

    def test_localhost_and_python_file_intents(self):
        self.assertEqual(plan_command("Open localhost:8000").actions[0].parameters["url"], "http://localhost:8000")
        self.assertEqual(plan_command("Create a Python file called test.py").actions[0].kind, "CREATE_PYTHON_FILE")
        self.assertEqual(plan_command("Run test.py").actions[0].kind, "RUN_PYTHON_FILE")

    def test_unknown_shell_text_is_not_executable(self):
        plan = plan_command("powershell Remove-Item important.txt")
        self.assertEqual(plan.actions, ())
        self.assertIn("couldn’t safely match", plan.message)


if __name__ == "__main__":
    unittest.main()