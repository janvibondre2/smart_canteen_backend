import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from desktop_assistant_modules.action_executor import ActionError, ActionExecutor
from desktop_assistant_modules.command_planner import plan_command
from desktop_assistant_modules.storage import AppStore


class AssistantSafetyTests(unittest.TestCase):
    def setUp(self):
        self.temporary_directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary_directory.cleanup)
        self.home = Path(self.temporary_directory.name) / "assistant-home"
        self.project = Path(self.temporary_directory.name) / "project"
        self.project.mkdir()
        environment = patch.dict("os.environ", {"AI_ASSISTANT_HOME": str(self.home)})
        environment.start()
        self.addCleanup(environment.stop)
        self.store = AppStore(self.project)
        self.executor = ActionExecutor(self.store)

    def test_requested_python_file_is_persisted_in_configured_folder(self):
        result = self.executor.execute(
            plan_command("Create a Python file called test.py"),
            "Create a Python file called test.py",
            lambda *_args: False,
        )
        expected = self.home / "projects" / "python" / "test.py"
        self.assertTrue(expected.is_file())
        self.assertIn(str(expected), result[0])

    def test_file_path_traversal_is_rejected(self):
        with self.assertRaises(ActionError):
            self.executor._save_python_file({"filename": "..\\outside.py"}, lambda *_args: True)

    def test_unsafe_url_is_rejected(self):
        with self.assertRaises(ActionError):
            self.executor._open_url("javascript:alert(1)")

    def test_running_code_requires_confirmation(self):
        script = self.store.python_projects_dir() / "test.py"
        script.write_text("print('safe test')", encoding="utf-8")
        result = self.executor.execute(plan_command("Run test.py"), "Run test.py", lambda *_args: False)
        self.assertEqual(result, ["Python execution was cancelled."])
        self.assertEqual(self.executor._children, {})

    def test_command_history_and_config_survive_reload(self):
        self.store.add_history("Open Chrome")
        restored = AppStore(self.project)
        self.assertEqual(restored.config["command_history"][-1]["command"], "Open Chrome")
        self.assertTrue((self.home / "config" / "config.json").is_file())


if __name__ == "__main__":
    unittest.main()