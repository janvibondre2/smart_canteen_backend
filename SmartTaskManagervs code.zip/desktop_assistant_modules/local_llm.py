"""Optional Ollama adapter; invalid model plans fall back to the local rules."""

from __future__ import annotations

import json
from urllib.error import URLError
from urllib.request import Request, urlopen

from desktop_assistant_modules.command_planner import Action, Plan


ALLOWED_ACTIONS = {
    "OPEN_APPLICATION": {"application"},
    "OPEN_URL": {"url"},
    "OPEN_FOLDER": {"folder"},
    "CREATE_PYTHON_FILE": {"filename"},
    "SAVE_PYTHON_FILE": {"filename", "content"},
    "RUN_PYTHON_FILE": {"filename"},
    "RUN_PYTHON_PROJECT": set(),
    "START_PROJECT_SERVER": set(),
    "CLOSE_APPLICATION": {"application"},
}


def plan_with_ollama(command: str, base_url: str, model: str) -> Plan | None:
    prompt = (
        "Convert the user's request into JSON only with this exact shape: "
        '{"actions":[{"kind":"OPEN_APPLICATION","parameters":{"application":"chrome"}}]}. '
        "Allowed kinds: " + ", ".join(sorted(ALLOWED_ACTIONS)) + ". "
        "Never invent file content, paths, URLs, commands, or application names. "
        "Only return actions directly requested by the user. If unclear, return {\"actions\":[]}.\n"
        f"User request: {command}"
    )
    body = json.dumps({"model": model, "prompt": prompt, "stream": False, "format": "json"}).encode("utf-8")
    request = Request(
        f"{base_url.rstrip('/')}/api/generate",
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urlopen(request, timeout=2.5) as response:
            output = json.loads(response.read().decode("utf-8"))
        parsed = json.loads(output.get("response", ""))
    except (OSError, ValueError, URLError, TimeoutError):
        return None

    planned = parsed.get("actions") if isinstance(parsed, dict) else None
    if not isinstance(planned, list) or not planned or len(planned) > 8:
        return None

    actions: list[Action] = []
    for item in planned:
        if not isinstance(item, dict):
            return None
        kind = item.get("kind")
        parameters = item.get("parameters", {})
        if kind not in ALLOWED_ACTIONS or not isinstance(parameters, dict):
            return None
        if set(parameters) - ALLOWED_ACTIONS[kind]:
            return None
        if not all(isinstance(value, str) for value in parameters.values()):
            return None
        actions.append(Action(kind, parameters))
    return Plan(tuple(actions))