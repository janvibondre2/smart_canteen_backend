"""Translate supported natural-language commands into explicit local actions."""

from __future__ import annotations

from dataclasses import dataclass, field
import re
from urllib.parse import quote_plus


@dataclass(frozen=True)
class Action:
    kind: str
    parameters: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class Plan:
    actions: tuple[Action, ...] = ()
    message: str = ""


def _segments(command: str) -> list[str]:
    return [
        part.strip(" ,.")
        for part in re.split(
            r"(?:\s+and\s+|,\s*)(?=(?:open|launch|start|search|go to|navigate|switch to|create|make|run|save|play)\b)",
            command,
            flags=re.IGNORECASE,
        )
        if part.strip(" ,.")
    ]


def _web_action(url: str) -> Action:
    return Action("OPEN_URL", {"url": url})


def _plan_segment(segment: str) -> list[Action]:
    text = segment.strip()
    normalized = text.lower()

    if "teams" in normalized and "meeting" in normalized and re.search(r"\b(?:check|show|open)\b", normalized):
        return [
            Action("OPEN_APPLICATION", {"application": "teams"}),
            _web_action("https://teams.microsoft.com/v2/"),
        ]

    if re.search(r"\b(?:open|launch|start)\s+all\s+(?:my\s+)?development\s+tools\b", normalized):
        return [
            Action("OPEN_APPLICATION", {"application": "vscode"}),
            Action("OPEN_APPLICATION", {"application": "terminal"}),
            Action("OPEN_APPLICATION", {"application": "explorer"}),
        ]

    youtube_search = re.search(r"(?:search\s+)?youtube\s+for\s+(.+)$", text, re.IGNORECASE)
    if youtube_search:
        query = youtube_search.group(1).strip(" \"'")
        return [_web_action(f"https://www.youtube.com/results?search_query={quote_plus(query)}")]

    google_search = re.search(r"(?:search\s+)?google\s+for\s+(.+)$", text, re.IGNORECASE)
    if google_search:
        query = google_search.group(1).strip(" \"'")
        return [_web_action(f"https://www.google.com/search?q={quote_plus(query)}")]

    google_suffix_search = re.search(r"\bsearch\s+(.+?)\s+on\s+google\b", text, re.IGNORECASE)
    if google_suffix_search:
        query = google_suffix_search.group(1).strip(" \"'")
        return [_web_action(f"https://www.google.com/search?q={quote_plus(query)}")]

    search_match = re.search(r"search\s+(?:the\s+web\s+)?for\s+(.+)$", text, re.IGNORECASE)
    if search_match:
        query = search_match.group(1).strip(" \"'")
        return [_web_action(f"https://www.google.com/search?q={quote_plus(query)}")]

    youtube_play = re.search(r"(?:play|find)\s+(.+?)\s+on\s+youtube\b", text, re.IGNORECASE)
    if youtube_play:
        query = youtube_play.group(1).strip(" \"'")
        return [_web_action(f"https://www.youtube.com/results?search_query={quote_plus(query)}")]

    if re.search(r"\b(?:open|go to|navigate to)\s+(?:youtube|youtube\.com)\b", normalized):
        return [_web_action("https://www.youtube.com")]

    if re.search(r"\b(?:open|go to|navigate to)\s+(?:google|google\.com)\b", normalized):
        return [_web_action("https://www.google.com")]

    local_url = re.search(r"\b(?:open|go to|navigate to)\s+(localhost(?::\d+)?(?:/[^\s]*)?)", text, re.IGNORECASE)
    if local_url:
        return [_web_action(f"http://{local_url.group(1)}")]

    url_match = re.search(r"\b(?:open|go to|navigate to)\s+(https?://[^\s]+|www\.[^\s]+)", text, re.IGNORECASE)
    if url_match:
        url = url_match.group(1).rstrip(".,)")
        return [_web_action(url if url.startswith("http") else f"https://{url}")]

    create_match = re.search(
        r"\b(?:create|make)\s+(?:a\s+)?(?:new\s+)?(?:python\s+)?file\s+(?:called|named)\s+([\w.-]+\.py)\b",
        text,
        re.IGNORECASE,
    )
    if create_match:
        return [Action("CREATE_PYTHON_FILE", {"filename": create_match.group(1)})]

    run_file = re.search(r"\b(?:run|execute)\s+([\w.-]+\.py)\b", text, re.IGNORECASE)
    if run_file:
        return [Action("RUN_PYTHON_FILE", {"filename": run_file.group(1)})]

    if re.search(r"\b(?:run|start)\s+(?:my\s+)?(?:python\s+)?project\s+(?:on\s+localhost|locally)\b", normalized):
        return [Action("START_PROJECT_SERVER")]

    if re.search(r"\b(?:start|run)\s+(?:my\s+)?(?:local\s+)?server\b", normalized):
        return [Action("START_PROJECT_SERVER")]

    if re.search(r"\b(?:run|start)\s+my\s+python\s+project\b", normalized):
        return [Action("RUN_PYTHON_PROJECT")]

    if re.search(r"\b(?:start|run)\s+(?:my\s+)?(?:react\s+)?application\b", normalized):
        return [Action("START_PROJECT_SERVER")]

    if re.search(r"\b(?:start|run)\s+my\s+backend\b", normalized):
        return [Action("START_PROJECT_SERVER")]

    if re.search(r"\b(?:open|show)\s+(?:my\s+)?(?:python\s+)?projects?\s+folder\b", normalized):
        return [Action("OPEN_FOLDER", {"folder": "python_projects"})]

    if re.search(r"\b(?:open|show)\s+(?:my\s+)?(?:ai\s+)?project(?:\s+folder)?\b", normalized):
        return [Action("OPEN_FOLDER", {"folder": "workspace"})]

    if re.search(r"\b(?:open|launch|start|switch to|bring up)\s+(?:google\s+)?chrome\b", normalized):
        return [Action("OPEN_APPLICATION", {"application": "chrome"})]

    if re.search(r"\b(?:open|launch|start|switch to|bring up)\s+(?:microsoft\s+)?teams\b", normalized):
        return [Action("OPEN_APPLICATION", {"application": "teams"})]

    if re.search(r"\b(?:open|launch|start|switch to|bring up)\s+(?:visual\s+studio\s+code|vs\s*code|vscode)\b", normalized):
        return [Action("OPEN_APPLICATION", {"application": "vscode"})]

    if re.search(r"\b(?:open|launch|start)\s+(?:file\s+)?explorer\b", normalized):
        return [Action("OPEN_APPLICATION", {"application": "explorer"})]

    if re.search(r"\b(?:open|launch|start)\s+(?:windows\s+)?terminal\b", normalized):
        return [Action("OPEN_APPLICATION", {"application": "terminal"})]

    if re.search(r"\b(?:open|launch|start)\s+(?:microsoft\s+)?edge\b", normalized):
        return [Action("OPEN_APPLICATION", {"application": "edge"})]

    close_match = re.search(r"\bclose\s+(chrome|edge|(?:microsoft\s+)?teams|(?:vs\s*code|vscode|visual\s+studio\s+code))\b", normalized)
    if close_match:
        target = close_match.group(1).replace("microsoft ", "")
        application = "vscode" if target in {"vs code", "vscode", "visual studio code"} else target
        return [Action("CLOSE_APPLICATION", {"application": application})]

    return []


def plan_command(command: str) -> Plan:
    """Return a typed plan, refusing to interpret unknown text as shell input."""
    command = command.strip()
    if not command:
        return Plan(message="Enter a command first.")

    youtube_workflow = re.search(
        r"\b(?:open|go to)\s+youtube(?:\.com)?\s+and\s+(?:search(?:\s+youtube)?\s+for|play)\s+(.+?)(?:\s+and\s+open\s+results)?$",
        command,
        re.IGNORECASE,
    )
    if youtube_workflow:
        query = youtube_workflow.group(1).strip(" \"'")
        return Plan((_web_action(f"https://www.youtube.com/results?search_query={quote_plus(query)}"),))

    code_match = re.search(r"```(?:python)?\s*([\s\S]*?)```", command, re.IGNORECASE)
    clean_command = re.sub(r"```(?:python)?\s*[\s\S]*?```", "", command, flags=re.IGNORECASE).strip()
    create_code = re.search(
        r"\b(?:save|create)\b[\s\S]*?\b(?:as|called|named)\s+([\w.-]+\.py)\b",
        clean_command,
        re.IGNORECASE,
    )
    if create_code and code_match:
        return Plan((Action("SAVE_PYTHON_FILE", {
            "filename": create_code.group(1),
            "content": code_match.group(1).strip() + "\n",
        }),))

    actions: list[Action] = []
    for segment in _segments(clean_command):
        actions.extend(_plan_segment(segment))

    if actions:
        return Plan(tuple(actions))
    return Plan(message="I couldn’t safely match that to a supported action. Try opening an app or URL, searching Google/YouTube, creating or running a Python file, or starting the current project server.")