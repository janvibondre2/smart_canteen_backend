"""Allow-listed Windows actions and project-aware local server launching."""

from __future__ import annotations

import json
import os
from pathlib import Path
import re
import shutil
import socket
import subprocess
import sys
import time
import webbrowser
from collections.abc import Callable
from urllib.parse import urlsplit

from desktop_assistant_modules.command_planner import Action, Plan
from desktop_assistant_modules.storage import AppStore


APP_NAMES = {
    "chrome": "Google Chrome",
    "edge": "Microsoft Edge",
    "teams": "Microsoft Teams",
    "vscode": "Visual Studio Code",
    "explorer": "File Explorer",
    "terminal": "Windows Terminal",
}


class ActionError(RuntimeError):
    pass


class ActionExecutor:
    def __init__(self, store: AppStore) -> None:
        self.store = store
        self._children: dict[int, subprocess.Popen] = {}

    def execute(self, plan: Plan, command: str, confirm) -> list[str]:
        results: list[str] = []
        for action in plan.actions:
            try:
                result = self._execute_action(action, confirm)
                results.append(result)
                self.store.write_activity(command, action.kind, result)
            except (ActionError, OSError, subprocess.SubprocessError) as error:
                result = f"Stopped after {len(results)} completed action(s): {error}"
                results.append(result)
                self.store.write_activity(command, action.kind, result)
                break
        return results

    def _execute_action(self, action: Action, confirm) -> str:
        parameters = action.parameters
        if action.kind == "OPEN_APPLICATION":
            return self._open_application(parameters.get("application", ""))
        if action.kind == "OPEN_URL":
            return self._open_url(parameters.get("url", ""))
        if action.kind == "OPEN_FOLDER":
            return self._open_folder(parameters.get("folder", "workspace"))
        if action.kind in {"CREATE_PYTHON_FILE", "SAVE_PYTHON_FILE"}:
            return self._save_python_file(parameters, confirm)
        if action.kind == "RUN_PYTHON_FILE":
            return self._run_python_file(parameters.get("filename", ""), confirm)
        if action.kind == "RUN_PYTHON_PROJECT":
            return self._run_python_project(confirm)
        if action.kind == "START_PROJECT_SERVER":
            return self._start_project_server()
        if action.kind == "CLOSE_APPLICATION":
            return self._close_application(parameters.get("application", ""), confirm)
        raise ActionError(f"Unsupported action: {action.kind}")

    def _open_application(self, name: str) -> str:
        name = name.lower().strip()
        if name not in APP_NAMES:
            raise ActionError("That application is not in the supported application list.")

        if name == "explorer":
            subprocess.Popen(["explorer.exe", str(self.store.workspace_dir())])
            return "Opened File Explorer at the current workspace."

        if name == "terminal":
            terminal = shutil.which("wt.exe") or shutil.which("wt")
            if terminal:
                subprocess.Popen([terminal], cwd=str(self.store.workspace_dir()))
            elif os.name == "nt":
                subprocess.Popen(["powershell.exe"], cwd=str(self.store.workspace_dir()))
            else:
                raise ActionError("Windows Terminal and PowerShell are only available on Windows.")
            return "Opened a terminal in the current workspace."

        if name == "teams":
            if os.name == "nt" and hasattr(os, "startfile"):
                try:
                    os.startfile("msteams:")
                    return "Opened Microsoft Teams. Sign-in remains under your control."
                except OSError:
                    self._open_url("https://teams.microsoft.com")
                    return "Opened Teams in your browser; authenticate normally if prompted."
            self._open_url("https://teams.microsoft.com")
            return "Opened Teams in your browser; authenticate normally if prompted."

        candidates = self._application_candidates(name)
        executable = next((path for path in candidates if Path(path).is_file()), None)
        if executable:
            arguments = [executable]
            if name == "vscode":
                arguments.append(str(self.store.workspace_dir()))
            subprocess.Popen(arguments)
            return f"Opened {APP_NAMES[name]}."

        command_names = {"chrome": "chrome.exe", "edge": "msedge.exe", "vscode": "code"}
        command = shutil.which(command_names[name])
        if command:
            subprocess.Popen([command, str(self.store.workspace_dir())] if name == "vscode" else [command])
            return f"Opened {APP_NAMES[name]}."

        if name in {"chrome", "edge"}:
            self._open_url("https://www.google.com")
            return f"Could not find {APP_NAMES[name]}; opened your configured browser instead."
        raise ActionError(f"Could not find {APP_NAMES[name]} on this computer.")

    @staticmethod
    def _application_candidates(name: str) -> list[str]:
        local = Path(os.getenv("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
        program_files = Path(os.getenv("ProgramFiles", r"C:\Program Files"))
        program_files_x86 = Path(os.getenv("ProgramFiles(x86)", r"C:\Program Files (x86)"))
        candidates = {
            "chrome": [
                program_files / "Google/Chrome/Application/chrome.exe",
                program_files_x86 / "Google/Chrome/Application/chrome.exe",
                local / "Google/Chrome/Application/chrome.exe",
            ],
            "edge": [
                program_files_x86 / "Microsoft/Edge/Application/msedge.exe",
                program_files / "Microsoft/Edge/Application/msedge.exe",
            ],
            "vscode": [
                local / "Programs/Microsoft VS Code/Code.exe",
                program_files / "Microsoft VS Code/Code.exe",
            ],
        }
        return [str(path) for path in candidates.get(name, [])]

    def _open_url(self, url: str) -> str:
        parsed = urlsplit(url)
        if parsed.scheme not in {"http", "https"} or not parsed.hostname:
            raise ActionError("Only valid HTTP/HTTPS websites can be opened.")
        browser = str(self.store.config.get("preferred_browser", "chrome")).lower()
        if browser in {"chrome", "edge"}:
            executable = next((path for path in self._application_candidates(browser) if Path(path).is_file()), None)
            if executable:
                subprocess.Popen([executable, url])
                return f"Opened {url} in {APP_NAMES[browser]}"
        opened = webbrowser.open(url, new=2)
        if not opened:
            raise ActionError("The configured browser did not accept the URL.")
        return f"Opened {url} in your default browser."

    def _open_folder(self, folder: str) -> str:
        targets = {
            "workspace": self.store.workspace_dir(),
            "python_projects": self.store.python_projects_dir(),
        }
        if folder not in targets:
            raise ActionError("That folder is not a supported saved location.")
        path = targets[folder]
        if not path.is_dir():
            raise ActionError(f"Folder does not exist: {path}")
        if os.name != "nt":
            raise ActionError("Opening folders with Explorer is only supported on Windows.")
        subprocess.Popen(["explorer.exe", str(path)])
        return f"Opened folder: {path}"

    @staticmethod
    def _safe_python_filename(filename: str) -> str:
        if not re.fullmatch(r"[A-Za-z0-9_.-]+\.py", filename, re.IGNORECASE) or filename in {".", ".."}:
            raise ActionError("Use a simple Python filename such as test.py; folder paths are not accepted.")
        return filename

    def _save_python_file(self, parameters: dict[str, str], confirm) -> str:
        filename = self._safe_python_filename(parameters.get("filename", ""))
        path = self.store.python_projects_dir() / filename
        content = parameters.get("content") or 'if __name__ == "__main__":\n    print("Hello from AI Assistant")\n'
        if len(content.encode("utf-8")) > 200_000:
            raise ActionError("The source is larger than the 200 KB limit for a single save operation.")
        if path.exists() and not confirm("Overwrite file?", f"This will replace the existing file:\n{path}\n\nContinue?"):
            return f"Kept the existing file unchanged: {path}"
        path.write_text(content, encoding="utf-8")
        return f"Saved Python file: {path}"

    def _run_python_file(self, filename: str, confirm) -> str:
        filename = self._safe_python_filename(filename)
        path = (self.store.python_projects_dir() / filename).resolve()
        if not path.is_file():
            raise ActionError(f"Python file not found in your Python projects folder: {path}")
        if not confirm("Run Python code?", f"This will execute the following local file:\n{path}\n\nContinue?"):
            return "Python execution was cancelled."
        return self._spawn_python(path)

    def _run_python_project(self, confirm) -> str:
        directory = self.store.python_projects_dir()
        scripts = [directory / name for name in ("main.py", "app.py", "run.py") if (directory / name).is_file()]
        if not scripts:
            scripts = sorted(path for path in directory.glob("*.py") if path.is_file())
        if not scripts:
            raise ActionError(f"No Python entry script found in {directory}. Add main.py or run a specific file.")
        script = scripts[0]
        if not confirm("Run Python project?", f"This will execute the local project entry point:\n{script}\n\nContinue?"):
            return "Python project execution was cancelled."
        return self._spawn_python(script)

    def _spawn_python(self, script: Path) -> str:
        self._ensure_python_projects_path(script)
        log_path = self.store.logs / f"python-{int(time.time())}.log"
        output = log_path.open("a", encoding="utf-8")
        process = subprocess.Popen(
            [sys.executable, str(script)],
            cwd=str(script.parent),
            stdout=output,
            stderr=subprocess.STDOUT,
            creationflags=self._detached_flags(),
        )
        output.close()
        self._children[process.pid] = process
        self.store.record_process({
            "pid": process.pid,
            "script": str(script),
            "log": str(log_path),
            "started_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        })
        return f"Started Python file {script.name} (PID {process.pid}); output is in {log_path}."

    def _ensure_python_projects_path(self, path: Path) -> None:
        try:
            path.resolve().relative_to(self.store.python_projects_dir().resolve())
        except ValueError as error:
            raise ActionError("Python execution is limited to files in the configured Python projects folder.") from error

    def _start_project_server(self) -> str:
        project = self.store.workspace_dir()
        if not project.is_dir():
            raise ActionError(f"Workspace folder does not exist: {project}")
        command, preferred_port, port_candidates, label = self._server_command(project)
        port = self._free_port(preferred_port)
        command = [str(port) if part == "{port}" else part for part in command]
        log_path = self.store.logs / f"server-{int(time.time())}.log"
        output = log_path.open("a", encoding="utf-8")
        try:
            process = subprocess.Popen(
                command,
                cwd=str(project),
                stdout=output,
                stderr=subprocess.STDOUT,
                creationflags=self._detached_flags(),
            )
        except OSError as error:
            output.close()
            raise ActionError(f"Could not start the project server: {error}") from error
        output.close()
        self._children[process.pid] = process
        actual_port = self._wait_for_server(process, port_candidates(port))
        if actual_port is None:
            details = self._tail(log_path)
            if process.poll() is not None:
                raise ActionError(f"The server exited during startup. See {log_path}. {details}")
            actual_port = port
            status = "Server process started; port has not responded yet"
        else:
            status = "Server is responding"
        url = f"http://localhost:{actual_port}"
        self.store.record_server({
            "pid": process.pid,
            "port": actual_port,
            "url": url,
            "project": str(project),
            "log": str(log_path),
            "started_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        })
        browser_result = self._open_url(url)
        return f"{status}: {label} at {url} (PID {process.pid}). {browser_result} Log: {log_path}"

    def _server_command(self, project: Path) -> tuple[list[str], int, Callable[[int], range | list[int]], str]:
        package_file = project / "package.json"
        if package_file.is_file():
            try:
                package = json.loads(package_file.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as error:
                raise ActionError(f"Could not read {package_file}: {error}") from error
            scripts = package.get("scripts", {})
            script_name = "dev" if "dev" in scripts else "start" if "start" in scripts else None
            if script_name:
                if not shutil.which("npm") and not shutil.which("npm.cmd"):
                    raise ActionError("Node.js/npm was not found. Install it or configure the project runtime first.")
                script_body = str(scripts[script_name]).lower()
                base_port = self._port_from_script(script_body) or (3000 if "next" in script_body else 5173)
                if "next" in script_body:
                    args = ["npm.cmd", "run", script_name, "--", "--hostname", "127.0.0.1", "--port", "{port}"]
                else:
                    args = ["npm.cmd", "run", script_name, "--", "--host", "127.0.0.1", "--port", "{port}"]
                return self._windows_command(args), base_port, lambda port: range(port, min(port + 11, 65536)), "Node development server"

        manage_py = project / "manage.py"
        if manage_py.is_file():
            port = self._free_port(8000)
            return [sys.executable, str(manage_py), "runserver", f"127.0.0.1:{port}"], port, lambda actual: [actual], "Django server"

        for module in ("main.py", "app.py"):
            candidate = project / module
            if candidate.is_file():
                source = candidate.read_text(encoding="utf-8", errors="replace")
                if re.search(r"\bFastAPI\s*\(", source):
                    port = self._free_port(8000)
                    return [sys.executable, "-m", "uvicorn", f"{candidate.stem}:app", "--host", "127.0.0.1", "--port", str(port)], port, lambda actual: [actual], "FastAPI server"
                if re.search(r"\bFlask\s*\(", source):
                    port = self._free_port(5000)
                    return [sys.executable, "-m", "flask", "--app", candidate.name, "run", "--host", "127.0.0.1", "--port", str(port)], port, lambda actual: [actual], "Flask server"

        if (project / "index.html").is_file():
            port = self._free_port(8000)
            return [sys.executable, "-m", "http.server", "{port}", "--bind", "127.0.0.1"], port, lambda actual: [actual], "Python static server"
        raise ActionError("No supported project entry point found. Expected package.json, manage.py, a FastAPI/Flask app, or index.html.")

    @staticmethod
    def _windows_command(arguments: list[str]) -> list[str]:
        if os.name == "nt":
            return ["cmd.exe", "/d", "/s", "/c", subprocess.list2cmdline(arguments)]
        npm = shutil.which("npm")
        if npm:
            arguments[0] = npm
            return arguments
        raise ActionError("npm is not available on PATH.")

    @staticmethod
    def _port_from_script(script: str) -> int | None:
        match = re.search(r"(?:--port\s+|PORT=)(\d{2,5})", script)
        if not match:
            return None
        port = int(match.group(1))
        return port if 1 <= port <= 65535 else None

    @staticmethod
    def _free_port(preferred: int) -> int:
        for port in range(preferred, min(preferred + 20, 65536)):
            with socket.socket() as probe:
                try:
                    probe.bind(("127.0.0.1", port))
                    return port
                except OSError:
                    continue
        raise ActionError(f"No free localhost port was found near {preferred}.")

    @staticmethod
    def _wait_for_server(process: subprocess.Popen, candidates) -> int | None:
        deadline = time.monotonic() + 8
        ports = list(candidates)
        while time.monotonic() < deadline and process.poll() is None:
            for port in ports:
                with socket.socket() as connection:
                    connection.settimeout(0.15)
                    if connection.connect_ex(("127.0.0.1", port)) == 0:
                        return port
            time.sleep(0.2)
        return None

    @staticmethod
    def _tail(path: Path) -> str:
        try:
            return " ".join(path.read_text(encoding="utf-8", errors="replace").splitlines()[-4:])
        except OSError:
            return ""

    def _close_application(self, name: str, confirm) -> str:
        name = name.lower().strip()
        process_names = {
            "chrome": "chrome.exe",
            "edge": "msedge.exe",
            "teams": "ms-teams.exe",
            "vscode": "Code.exe",
        }
        if name not in process_names:
            raise ActionError("Only Chrome, Edge, Teams, and VS Code can be closed by this assistant.")
        image = process_names[name]
        if not confirm("Close application?", f"This will ask Windows to close all {APP_NAMES[name]} processes ({image}). Unsaved work may be affected. Continue?"):
            return "Application close was cancelled."
        completed = subprocess.run(["taskkill.exe", "/IM", image, "/T"], capture_output=True, text=True, check=False)
        if completed.returncode != 0:
            detail = (completed.stderr or completed.stdout).strip()
            if "not found" in detail.lower():
                return f"{APP_NAMES[name]} is not running."
            raise ActionError(detail or f"Windows could not close {APP_NAMES[name]}.")
        return f"Asked Windows to close {APP_NAMES[name]}."

    @staticmethod
    def _detached_flags() -> int:
        if os.name == "nt":
            return getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0) | getattr(subprocess, "DETACHED_PROCESS", 0)
        return 0