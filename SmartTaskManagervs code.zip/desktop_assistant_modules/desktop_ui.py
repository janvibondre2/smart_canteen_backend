"""Tkinter desktop interface for the local computer assistant."""

from __future__ import annotations

import threading
import socket
import tkinter as tk
from tkinter import messagebox, ttk
from tkinter.scrolledtext import ScrolledText
from pathlib import Path

from desktop_assistant_modules.action_executor import ActionExecutor
from desktop_assistant_modules.command_planner import Action, Plan, plan_command
from desktop_assistant_modules.local_llm import plan_with_ollama
from desktop_assistant_modules.storage import AppStore


COLORS = {
    "background": "#111815",
    "panel": "#18221d",
    "panel_alt": "#202c26",
    "border": "#33443a",
    "text": "#e7eee9",
    "muted": "#a6b5aa",
    "accent": "#9ddd72",
    "accent_text": "#142113",
    "warning": "#f2c879",
}


class AssistantWindow:
    def __init__(self, store: AppStore) -> None:
        self.store = store
        self.executor = ActionExecutor(store)
        self.root = tk.Tk()
        self.root.title("Local AI Computer Assistant")
        self.root.geometry("1050x720")
        self.root.minsize(820, 580)
        self.root.configure(bg=COLORS["background"])
        self.busy = False
        self._configure_style()
        self._build_layout()
        self._refresh_sidebar()
        self.root.after(5000, self._refresh_sidebar)

    def _configure_style(self) -> None:
        style = ttk.Style(self.root)
        style.theme_use("clam")
        style.configure("TFrame", background=COLORS["background"])
        style.configure("Panel.TFrame", background=COLORS["panel"])
        style.configure("TLabel", background=COLORS["background"], foreground=COLORS["text"], font=("Segoe UI", 10))
        style.configure("Muted.TLabel", background=COLORS["panel"], foreground=COLORS["muted"], font=("Segoe UI", 9))
        style.configure("Title.TLabel", font=("Segoe UI Semibold", 18), foreground=COLORS["text"])
        style.configure("Section.TLabel", background=COLORS["panel"], foreground=COLORS["text"], font=("Segoe UI Semibold", 10))
        style.configure("TButton", font=("Segoe UI Semibold", 9), padding=(12, 8), background=COLORS["panel_alt"], foreground=COLORS["text"])
        style.map("TButton", background=[("active", COLORS["border"])])
        style.configure("Run.TButton", font=("Segoe UI Semibold", 10), padding=(18, 10), background=COLORS["accent"], foreground=COLORS["accent_text"])
        style.map("Run.TButton", background=[("active", "#b1e88c")])
        style.configure("TEntry", fieldbackground=COLORS["panel_alt"], foreground=COLORS["text"], insertcolor=COLORS["text"], padding=10)
        style.configure("TCheckbutton", background=COLORS["panel"], foreground=COLORS["text"])
        style.configure("TCombobox", fieldbackground=COLORS["panel_alt"], foreground=COLORS["text"], padding=6)

    def _build_layout(self) -> None:
        header = ttk.Frame(self.root, padding=(22, 18, 22, 12))
        header.pack(fill="x")
        title_area = ttk.Frame(header)
        title_area.pack(side="left", fill="x", expand=True)
        ttk.Label(title_area, text="LOCAL AI COMPUTER ASSISTANT", style="Title.TLabel").pack(anchor="w")
        ttk.Label(title_area, text="Private, local-first control for your Windows workspace").pack(anchor="w", pady=(3, 0))
        ttk.Button(header, text="Settings", command=self._open_settings).pack(side="right", anchor="n")

        body = ttk.Frame(self.root, padding=(18, 4, 18, 16))
        body.pack(fill="both", expand=True)
        sidebar = ttk.Frame(body, style="Panel.TFrame", padding=15, width=255)
        sidebar.pack(side="left", fill="y", padx=(0, 12))
        sidebar.pack_propagate(False)
        self._build_sidebar(sidebar)

        content = ttk.Frame(body, style="Panel.TFrame", padding=14)
        content.pack(side="left", fill="both", expand=True)
        ttk.Label(content, text="Command session", style="Section.TLabel").pack(anchor="w", pady=(0, 8))
        self.transcript = ScrolledText(
            content,
            wrap="word",
            state="disabled",
            background=COLORS["panel"],
            foreground=COLORS["text"],
            insertbackground=COLORS["text"],
            selectbackground=COLORS["border"],
            relief="flat",
            padx=10,
            pady=10,
            font=("Segoe UI", 10),
        )
        self.transcript.pack(fill="both", expand=True)
        self.transcript.tag_configure("user", foreground=COLORS["accent"], font=("Segoe UI Semibold", 10))
        self.transcript.tag_configure("assistant", foreground=COLORS["text"])
        self.transcript.tag_configure("plan", foreground=COLORS["warning"])
        self.transcript.tag_configure("muted", foreground=COLORS["muted"])
        self._append("assistant", "Ready. Try: Open Chrome, search Google for internships, open Teams, create a Python file called test.py, or start this project on localhost.")

        self.status = tk.StringVar(value="Ready")
        status_row = ttk.Frame(content, style="Panel.TFrame")
        status_row.pack(fill="x", pady=(10, 8))
        ttk.Label(status_row, textvariable=self.status, style="Muted.TLabel").pack(side="left")
        ttk.Label(status_row, text="Unknown shell commands are never executed.", style="Muted.TLabel").pack(side="right")

        command_row = ttk.Frame(content, style="Panel.TFrame")
        command_row.pack(fill="x")
        self.command_input = ttk.Entry(command_row)
        self.command_input.pack(side="left", fill="x", expand=True, padx=(0, 8))
        self.command_input.bind("<Return>", self._submit_event)
        self.run_button = ttk.Button(command_row, text="Run command", style="Run.TButton", command=self._submit)
        self.run_button.pack(side="right")

    def _build_sidebar(self, parent: ttk.Frame) -> None:
        ttk.Label(parent, text="WORKSPACE", style="Section.TLabel").pack(anchor="w")
        self.workspace_label = ttk.Label(parent, text="", style="Muted.TLabel", wraplength=220)
        self.workspace_label.pack(anchor="w", fill="x", pady=(5, 10))
        ttk.Button(parent, text="Open workspace", command=lambda: self._run_quick("Open my project folder")).pack(fill="x")
        ttk.Button(parent, text="Open Python projects", command=lambda: self._run_quick("Open my Python projects folder")).pack(fill="x", pady=(6, 14))

        ttk.Label(parent, text="LOCALHOST SERVERS", style="Section.TLabel").pack(anchor="w")
        self.servers = tk.Listbox(
            parent,
            height=6,
            bg=COLORS["panel_alt"],
            fg=COLORS["text"],
            selectbackground=COLORS["border"],
            relief="flat",
            highlightthickness=0,
            font=("Segoe UI", 9),
        )
        self.servers.pack(fill="x", pady=(6, 14))

        ttk.Label(parent, text="RECENT COMMANDS", style="Section.TLabel").pack(anchor="w")
        self.history = tk.Listbox(
            parent,
            height=8,
            bg=COLORS["panel_alt"],
            fg=COLORS["text"],
            selectbackground=COLORS["border"],
            relief="flat",
            highlightthickness=0,
            font=("Segoe UI", 9),
        )
        self.history.pack(fill="both", expand=True, pady=(6, 0))
        self.history.bind("<<ListboxSelect>>", self._select_history)

    def _append(self, role: str, text: str, tag: str | None = None) -> None:
        self.transcript.configure(state="normal")
        self.transcript.insert("end", f"\n{role}: ", role if role in {"user", "assistant"} else "muted")
        self.transcript.insert("end", text + "\n", tag or (role if role in {"user", "assistant"} else "muted"))
        self.transcript.see("end")
        self.transcript.configure(state="disabled")

    def _submit_event(self, _event) -> str:
        self._submit()
        return "break"

    def _submit(self) -> None:
        if self.busy:
            return
        command = self.command_input.get().strip()
        if not command:
            return
        self.command_input.delete(0, "end")
        self._append("user", command)
        self.store.add_history(command)
        self._refresh_sidebar()
        self._set_busy(True, "Planning safe actions...")
        threading.Thread(target=self._plan_and_execute, args=(command,), daemon=True).start()

    def _plan_and_execute(self, command: str) -> None:
        plan: Plan | None = None
        if self.store.config.get("ollama_enabled"):
            plan = plan_with_ollama(
                command,
                str(self.store.config.get("ollama_base_url", "http://127.0.0.1:11434")),
                str(self.store.config.get("ollama_model", "llama3.2")),
            )
        if plan is None or not plan.actions:
            plan = plan_command(command)
        if not plan.actions:
            self.root.after(0, self._finish, plan.message or "No safe action was recognized.")
            return

        plan_text = "\n".join(f"{index}. {self._describe(action)}" for index, action in enumerate(plan.actions, 1))
        self.root.after(0, self._append, "assistant", f"Plan:\n{plan_text}", "plan")
        self.root.after(0, self.status.set, "Executing planned actions...")
        results = self.executor.execute(plan, command, self._confirm_from_worker)
        self.root.after(0, self._finish, "\n".join(results))

    @staticmethod
    def _describe(action: Action) -> str:
        parameters = action.parameters
        labels = {
            "OPEN_APPLICATION": f"Open {parameters.get('application', 'application')}",
            "OPEN_URL": f"Open {parameters.get('url', 'website')}",
            "OPEN_FOLDER": f"Open {parameters.get('folder', 'saved')} folder",
            "CREATE_PYTHON_FILE": f"Create {parameters.get('filename', 'Python file')} in Python projects",
            "SAVE_PYTHON_FILE": f"Save supplied code as {parameters.get('filename', 'Python file')}",
            "RUN_PYTHON_FILE": f"Run {parameters.get('filename', 'Python file')} (confirmation required)",
            "RUN_PYTHON_PROJECT": "Run the configured Python project (confirmation required)",
            "START_PROJECT_SERVER": "Start the configured project server",
            "CLOSE_APPLICATION": f"Close {parameters.get('application', 'application')} (confirmation required)",
        }
        return labels.get(action.kind, action.kind)

    def _confirm_from_worker(self, title: str, details: str) -> bool:
        result: dict[str, bool] = {}
        finished = threading.Event()

        def ask() -> None:
            result["approved"] = messagebox.askyesno(title, details, parent=self.root)
            finished.set()

        self.root.after(0, ask)
        finished.wait()
        return result.get("approved", False)

    def _finish(self, result: str) -> None:
        self._append("assistant", result)
        self._set_busy(False, "Ready")
        self._refresh_sidebar()

    def _set_busy(self, busy: bool, status: str) -> None:
        self.busy = busy
        self.status.set(status)
        self.run_button.configure(state="disabled" if busy else "normal")

    def _run_quick(self, command: str) -> None:
        if self.busy:
            return
        self.command_input.delete(0, "end")
        self.command_input.insert(0, command)
        self._submit()

    def _select_history(self, _event) -> None:
        selected = self.history.curselection()
        if not selected:
            return
        history = self.store.config.get("command_history", [])
        item = list(reversed(history[-8:]))[selected[0]]
        self.command_input.delete(0, "end")
        self.command_input.insert(0, item.get("command", ""))

    def _refresh_sidebar(self) -> None:
        self.workspace_label.configure(text=str(self.store.workspace_dir()))
        self.servers.delete(0, "end")
        for server in reversed(self.store.config.get("running_servers", [])[-8:]):
            port = int(server.get("port", 0))
            with socket.socket() as probe:
                probe.settimeout(0.1)
                active = bool(port and probe.connect_ex(("127.0.0.1", port)) == 0)
            marker = "Responding" if active else "No response"
            self.servers.insert("end", f"{marker}: {server.get('url', 'unknown')} (PID {server.get('pid', '?')})")
        self.history.delete(0, "end")
        for item in reversed(self.store.config.get("command_history", [])[-8:]):
            self.history.insert("end", item.get("command", "")[:54])
        processes = self.store.config.get("running_processes", [])
        if processes:
            self.servers.insert("end", "")
            self.servers.insert("end", "Python processes:")
            for process in reversed(processes[-4:]):
                self.servers.insert("end", f"{Path(process.get('script', '')).name} (PID {process.get('pid', '?')})")
        self.root.after(5000, self._refresh_sidebar)

    def _open_settings(self) -> None:
        window = tk.Toplevel(self.root)
        window.title("Assistant settings")
        window.configure(bg=COLORS["background"])
        window.transient(self.root)
        window.grab_set()
        window.resizable(False, False)
        frame = ttk.Frame(window, style="Panel.TFrame", padding=18)
        frame.pack(fill="both", expand=True)

        fields: dict[str, tk.StringVar] = {}
        definitions = [
            ("workspace_dir", "Workspace folder"),
            ("python_projects_dir", "Python projects folder"),
            ("ollama_base_url", "Ollama URL"),
            ("ollama_model", "Ollama model"),
        ]
        for row, (key, label) in enumerate(definitions):
            ttk.Label(frame, text=label, style="Section.TLabel").grid(row=row, column=0, sticky="w", pady=5, padx=(0, 12))
            value = tk.StringVar(value=str(self.store.config.get(key, "")))
            fields[key] = value
            ttk.Entry(frame, textvariable=value, width=58).grid(row=row, column=1, sticky="ew", pady=5)
        ttk.Label(frame, text="Preferred browser", style="Section.TLabel").grid(row=4, column=0, sticky="w", pady=5)
        browser = tk.StringVar(value=str(self.store.config.get("preferred_browser", "chrome")))
        ttk.Combobox(frame, textvariable=browser, values=("chrome", "edge"), state="readonly", width=55).grid(row=4, column=1, sticky="ew", pady=5)
        enabled = tk.BooleanVar(value=bool(self.store.config.get("ollama_enabled", False)))
        ttk.Checkbutton(frame, text="Use local Ollama model when available", variable=enabled).grid(row=5, column=1, sticky="w", pady=(8, 12))
        ttk.Label(frame, text="Ollama is optional; commands stay on this PC and use built-in rules when disabled or unavailable.", style="Muted.TLabel", wraplength=470).grid(row=6, column=0, columnspan=2, sticky="w", pady=(0, 14))

        def save() -> None:
            workspace = Path(fields["workspace_dir"].get()).expanduser()
            python_directory = Path(fields["python_projects_dir"].get()).expanduser()
            if not workspace.is_dir():
                messagebox.showerror("Invalid workspace", "The workspace folder must already exist.", parent=window)
                return
            try:
                python_directory.mkdir(parents=True, exist_ok=True)
            except OSError as error:
                messagebox.showerror("Invalid Python folder", str(error), parent=window)
                return
            self.store.update_settings({
                "workspace_dir": str(workspace.resolve()),
                "python_projects_dir": str(python_directory.resolve()),
                "ollama_base_url": fields["ollama_base_url"].get().strip().rstrip("/"),
                "ollama_model": fields["ollama_model"].get().strip(),
                "preferred_browser": browser.get(),
                "ollama_enabled": enabled.get(),
            })
            self._refresh_sidebar()
            window.destroy()

        ttk.Button(frame, text="Save settings", style="Run.TButton", command=save).grid(row=7, column=1, sticky="e", pady=(4, 0))
        frame.columnconfigure(1, weight=1)

    def run(self) -> None:
        self.root.mainloop()


def run_desktop_app(store: AppStore) -> None:
    AssistantWindow(store).run()