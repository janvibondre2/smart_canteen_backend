"""Configuration and environment helpers for the desktop assistant modules."""

from .settings import load_settings

__all__ = ["load_settings"]
