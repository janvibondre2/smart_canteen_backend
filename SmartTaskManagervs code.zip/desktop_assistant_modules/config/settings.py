"""Environment and configuration loading for the desktop assistant modules."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Dict, Any

from dotenv import load_dotenv


BASE_DIR = Path(__file__).resolve().parents[1]
load_dotenv(BASE_DIR / ".env")


def load_settings() -> Dict[str, Any]:
    """Read environment variables and return them as a dictionary."""
    return {
        "OLLAMA_BASE_URL": os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434"),
        "PIPER_HOST": os.getenv("PIPER_HOST", "127.0.0.1"),
        "PIPER_PORT": os.getenv("PIPER_PORT", "5000"),
        "CHROMA_DB_PATH": os.getenv("CHROMA_DB_PATH", str(BASE_DIR / ".data" / "chroma")),
        "SQLITE_DB_PATH": os.getenv("SQLITE_DB_PATH", str(BASE_DIR / ".data" / "app.db")),
        "POSTGRES_DSN": os.getenv("POSTGRES_DSN", "postgresql+psycopg2://user:password@localhost:5432/desktop_assistant"),
        "USE_POSTGRES": os.getenv("USE_POSTGRES", "false").lower() == "true",
        "ELECTRON_BRIDGE_PORT": os.getenv("ELECTRON_BRIDGE_PORT", "8001"),
        "LOG_LEVEL": os.getenv("LOG_LEVEL", "INFO"),
    }
