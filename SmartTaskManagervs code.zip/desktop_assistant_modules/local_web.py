"""Loopback-only web UI and command API for the desktop assistant."""

from __future__ import annotations

import json
import threading
import uuid
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from desktop_assistant_modules.action_executor import ActionExecutor
from desktop_assistant_modules.command_planner import Action, Plan, plan_command
from desktop_assistant_modules.local_llm import plan_with_ollama
from desktop_assistant_modules.storage import AppStore


class AssistantService:
    def __init__(self, store: AppStore) -> None:
        self.store = store
        self.executor = ActionExecutor(store)
        self._lock = threading.RLock()
        self._running = False
        self._messages: list[dict[str, str]] = []
        self._status = "Ready"
        self._pending: dict[str, Any] | None = None

    def submit(self, command: str) -> bool:
        command = command.strip()
        if not command:
            return False
        if len(command) > 4000:
            raise ValueError("Commands must be 4,000 characters or shorter.")
        with self._lock:
            if self._running:
                return False
            self._running = True
            self._status = "Planning command"
            self._messages.append({"role": "user", "text": command})
            self.store.add_history(command)
        threading.Thread(target=self._plan_and_execute, args=(command,), daemon=True).start()
        return True

    def _plan_and_execute(self, command: str) -> None:
        plan: Plan | None = None
        if self.store.config.get("ollama_enabled"):
            plan = plan_with_ollama(
                command,
                str(self.store.config.get("ollama_base_url", "http://127.0.0.1:11434")),
                str(self.store.config.get("ollama_model", "llama3.2")),
            )
        if plan is None or not plan.actions:
            plan = plan_command(command)

        if not plan.actions:
            self._append_message(plan.message or "No safe action was recognized.")
            self._finish()
            return

        descriptions = [self._describe(action) for action in plan.actions]
        self._append_message("Plan:\n" + "\n".join(f"{i}. {description}" for i, description in enumerate(descriptions, 1)))
        with self._lock:
            self._status = "Executing planned actions"

        results = self.executor.execute(plan, command, self._confirm)
        self._append_message("\n".join(results))
        self._finish()

    def _confirm(self, title: str, details: str) -> bool:
        event = threading.Event()
        confirmation_id = uuid.uuid4().hex
        pending = {
            "id": confirmation_id,
            "title": title,
            "details": details,
            "event": event,
            "approved": False,
        }
        with self._lock:
            self._pending = pending
            self._status = "Waiting for confirmation"
        if not event.wait(timeout=120):
            with self._lock:
                self._pending = None
                self._status = "Confirmation timed out"
            return False
        with self._lock:
            approved = bool(pending["approved"])
            if self._pending is pending:
                self._pending = None
            self._status = "Executing planned actions" if approved else "Action cancelled"
        return approved

    def confirm(self, confirmation_id: str, approved: bool) -> bool:
        with self._lock:
            pending = self._pending
            if not pending or pending["id"] != confirmation_id:
                return False
            pending["approved"] = approved
            pending["event"].set()
            return True

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            pending = self._pending
            return {
                "busy": self._running,
                "status": self._status,
                "messages": self._messages[-100:],
                "history": self.store.config.get("command_history", [])[-20:],
                "servers": self.store.config.get("running_servers", [])[-20:],
                "processes": self.store.config.get("running_processes", [])[-20:],
                "workspace": str(self.store.workspace_dir()),
                "python_projects": str(self.store.python_projects_dir()),
                "preferred_browser": self.store.config.get("preferred_browser", "chrome"),
                "ollama_enabled": bool(self.store.config.get("ollama_enabled")),
                "ollama_base_url": self.store.config.get("ollama_base_url", "http://127.0.0.1:11434"),
                "ollama_model": self.store.config.get("ollama_model", "llama3.2"),
                "confirmation": ({
                    "id": pending["id"],
                    "title": pending["title"],
                    "details": pending["details"],
                } if pending else None),
            }

    def save_settings(self, settings: dict[str, Any]) -> None:
        allowed = {
            "workspace_dir",
            "python_projects_dir",
            "preferred_browser",
            "ollama_enabled",
            "ollama_base_url",
            "ollama_model",
        }
        if set(settings) - allowed:
            raise ValueError("Unsupported settings were supplied.")
        workspace = Path(str(settings.get("workspace_dir", self.store.config["workspace_dir"]))).expanduser().resolve()
        python_projects = Path(str(settings.get("python_projects_dir", self.store.config["python_projects_dir"]))).expanduser().resolve()
        if not workspace.is_dir():
            raise ValueError("Workspace folder must already exist.")
        python_projects.mkdir(parents=True, exist_ok=True)
        browser = settings.get("preferred_browser", self.store.config.get("preferred_browser", "chrome"))
        if browser not in {"chrome", "edge"}:
            raise ValueError("Preferred browser must be Chrome or Edge.")
        model = str(settings.get("ollama_model", self.store.config.get("ollama_model", "llama3.2"))).strip()
        base_url = str(settings.get("ollama_base_url", self.store.config.get("ollama_base_url", "http://127.0.0.1:11434"))).strip().rstrip("/")
        if urlsplit(base_url).scheme != "http" or urlsplit(base_url).hostname not in {"127.0.0.1", "localhost", "::1"}:
            raise ValueError("Ollama must use an HTTP endpoint on this computer.")
        self.store.update_settings({
            "workspace_dir": str(workspace),
            "python_projects_dir": str(python_projects),
            "preferred_browser": browser,
            "ollama_enabled": bool(settings.get("ollama_enabled", self.store.config.get("ollama_enabled", False))),
            "ollama_base_url": base_url,
            "ollama_model": model or "llama3.2",
        })

    def _append_message(self, text: str) -> None:
        with self._lock:
            self._messages.append({"role": "assistant", "text": text})
            self._messages = self._messages[-100:]

    def _finish(self) -> None:
        with self._lock:
            self._running = False
            self._status = "Ready"

    @staticmethod
    def _describe(action: Action) -> str:
        values = action.parameters
        labels = {
            "OPEN_APPLICATION": f"Open {values.get('application', 'application')}",
            "OPEN_URL": f"Open {values.get('url', 'website')}",
            "OPEN_FOLDER": f"Open {values.get('folder', 'saved')} folder",
            "CREATE_PYTHON_FILE": f"Create {values.get('filename', 'Python file')} in Python projects",
            "SAVE_PYTHON_FILE": f"Save supplied code as {values.get('filename', 'Python file')}",
            "RUN_PYTHON_FILE": f"Run {values.get('filename', 'Python file')} (confirmation required)",
            "RUN_PYTHON_PROJECT": "Run the configured Python project (confirmation required)",
            "START_PROJECT_SERVER": "Start the configured project server",
            "CLOSE_APPLICATION": f"Close {values.get('application', 'application')} (confirmation required)",
        }
        return labels.get(action.kind, action.kind)


def create_server(service: AssistantService, port: int = 8765) -> ThreadingHTTPServer:
    page = Path(__file__).with_name("assistant.html").read_bytes()

    class AssistantHandler(BaseHTTPRequestHandler):
        server_version = "LocalAssistant/1.0"

        def do_GET(self) -> None:
            if not self._is_local_host():
                self.send_error(403)
                return
            if self.path in {"/", "/index.html"}:
                self._send(200, page, "text/html; charset=utf-8")
            elif self.path == "/api/status":
                self._json(200, service.snapshot())
            else:
                self.send_error(404)

        def do_POST(self) -> None:
            if not self._is_local_host():
                self.send_error(403)
                return
            if self.headers.get_content_type() != "application/json":
                self._json(415, {"error": "Send a JSON request body."})
                return
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length <= 0 or length > 64_000:
                    raise ValueError("Request must be between 1 and 64,000 bytes.")
                data = json.loads(self.rfile.read(length).decode("utf-8"))
                if not isinstance(data, dict):
                    raise ValueError("Request body must be a JSON object.")
                if self.path == "/api/command":
                    command = data.get("command")
                    if not isinstance(command, str):
                        raise ValueError("Command must be text.")
                    if not service.submit(command):
                        self._json(409, {"error": "The assistant is already processing a command, or the command is empty."})
                    else:
                        self._json(202, {"accepted": True})
                elif self.path == "/api/confirm":
                    confirmation_id = data.get("id")
                    approved = data.get("approved")
                    if not isinstance(confirmation_id, str) or not isinstance(approved, bool):
                        raise ValueError("Confirmation requires an id and an approval decision.")
                    if service.confirm(confirmation_id, approved):
                        self._json(200, {"accepted": True})
                    else:
                        self._json(409, {"error": "This confirmation is no longer active."})
                elif self.path == "/api/settings":
                    service.save_settings(data)
                    self._json(200, {"saved": True})
                else:
                    self.send_error(404)
            except (ValueError, json.JSONDecodeError) as error:
                self._json(400, {"error": str(error)})
            except OSError as error:
                self._json(500, {"error": str(error)})

        def _is_local_host(self) -> bool:
            if self.client_address[0] not in {"127.0.0.1", "::1"}:
                return False
            host = self.headers.get("Host", "").split(":", 1)[0].strip("[]").lower()
            return host in {"localhost", "127.0.0.1", "::1"}

        def _send(self, status: int, content: bytes, content_type: str) -> None:
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(content)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Content-Security-Policy", "default-src 'self'; connect-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; img-src 'self' data:")
            self.end_headers()
            self.wfile.write(content)

        def _json(self, status: int, value: dict[str, Any]) -> None:
            body = json.dumps(value, ensure_ascii=True).encode("utf-8")
            self._send(status, body, "application/json; charset=utf-8")

        def log_message(self, _format: str, *_args: Any) -> None:
            return

    server = ThreadingHTTPServer(("127.0.0.1", port), AssistantHandler)
    server.daemon_threads = True
    return server


def main(store: AppStore) -> None:
    service = AssistantService(store)
    last_error: OSError | None = None
    for port in range(8765, 8780):
        try:
            server = create_server(service, port)
            break
        except OSError as error:
            last_error = error
    else:
        raise RuntimeError(f"Could not reserve a localhost port for the assistant: {last_error}")

    url = f"http://127.0.0.1:{server.server_port}/"
    print(f"Local AI Computer Assistant running at {url}", flush=True)
    webbrowser.open(url, new=2)
    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()