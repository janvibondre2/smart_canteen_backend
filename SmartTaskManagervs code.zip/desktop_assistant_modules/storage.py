"""Persistent configuration, command history, and activity logging."""

from __future__ import annotations

import json
import os
from pathlib import Path
import re
from datetime import datetime, timezone
from typing import Any


def default_home() -> Path:
    configured = os.getenv("AI_ASSISTANT_HOME")
    return Path(configured).expanduser() if configured else Path.home() / "AI_Assistant"


def _redact(text: str) -> str:
    text = re.sub(r"```[\s\S]*?```", "[code omitted]", text)
    text = re.sub(
        r"(?i)(password|passwd|token|api[_-]?key|secret)\s*[:=]\s*[^\s,;]+",
        r"\1=[redacted]",
        text,
    )
    return text


class AppStore:
    def __init__(self, app_directory: Path) -> None:
        self.app_directory = app_directory.resolve()
        self.home = default_home().resolve()
        self.projects = self.home / "projects"
        self.python_projects = self.projects / "python"
        self.logs = self.home / "logs"
        self.config_directory = self.home / "config"
        self.config_path = self.config_directory / "config.json"
        self.activity_log = self.logs / "activity.log"
        self._ensure_directories()
        self.config = self._load_config()

    def _ensure_directories(self) -> None:
        for path in (
            self.home,
            self.projects,
            self.python_projects,
            self.projects / "web",
            self.projects / "cybersecurity",
            self.projects / "ai_ml",
            self.projects / "scripts",
            self.logs,
            self.config_directory,
        ):
            path.mkdir(parents=True, exist_ok=True)

    def _defaults(self) -> dict[str, Any]:
        return {
            "workspace_dir": str(self.app_directory),
            "python_projects_dir": str(self.python_projects),
            "preferred_browser": "chrome",
            "ollama_enabled": False,
            "ollama_base_url": "http://127.0.0.1:11434",
            "ollama_model": "llama3.2",
            "command_history": [],
            "running_servers": [],
            "running_processes": [],
        }

    def _load_config(self) -> dict[str, Any]:
        settings = self._defaults()
        try:
            stored = json.loads(self.config_path.read_text(encoding="utf-8"))
            if isinstance(stored, dict):
                settings.update(stored)
        except (OSError, json.JSONDecodeError):
            pass
        self.config = settings
        self.save_config()
        return settings

    def save_config(self) -> None:
        temporary = self.config_path.with_suffix(".tmp")
        temporary.write_text(json.dumps(self.config, indent=2), encoding="utf-8")
        temporary.replace(self.config_path)

    def update_settings(self, values: dict[str, Any]) -> None:
        self.config.update(values)
        self.save_config()

    def workspace_dir(self) -> Path:
        return Path(self.config["workspace_dir"]).expanduser().resolve()

    def python_projects_dir(self) -> Path:
        path = Path(self.config["python_projects_dir"]).expanduser().resolve()
        path.mkdir(parents=True, exist_ok=True)
        return path

    def add_history(self, command: str) -> None:
        history = self.config.setdefault("command_history", [])
        history.append({"time": datetime.now(timezone.utc).isoformat(), "command": _redact(command)})
        self.config["command_history"] = history[-100:]
        self.save_config()

    def record_server(self, record: dict[str, Any]) -> None:
        servers = self.config.setdefault("running_servers", [])
        servers = [item for item in servers if item.get("pid") != record.get("pid")]
        servers.append(record)
        self.config["running_servers"] = servers[-30:]
        self.save_config()

    def record_process(self, record: dict[str, Any]) -> None:
        processes = self.config.setdefault("running_processes", [])
        processes = [item for item in processes if item.get("pid") != record.get("pid")]
        processes.append(record)
        self.config["running_processes"] = processes[-30:]
        self.save_config()

    def write_activity(self, command: str, action: str, result: str) -> None:
        timestamp = datetime.now().astimezone().isoformat(timespec="seconds")
        line = f"{timestamp} | command={_redact(command)} | action={action} | result={_redact(result)}\n"
        with self.activity_log.open("a", encoding="utf-8") as log_file:
            log_file.write(line)