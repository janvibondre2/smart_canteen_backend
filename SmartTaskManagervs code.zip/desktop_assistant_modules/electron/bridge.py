"""Simple bridge abstraction for Electron to communicate with Python modules."""

from __future__ import annotations

from typing import Any, Dict

from utils.logging_config import get_logger


logger = get_logger("electron.bridge")


class ElectronBridge:
    """A lightweight bridge for desktop shell events and Python automation."""

    def __init__(self, port: int = 8001) -> None:
        self.port = port

    def send_event(self, event_name: str, payload: Dict[str, Any] | None = None) -> Dict[str, Any]:
        """Emit a simple event payload that can be consumed by Electron."""
        event_payload = {"event": event_name, "payload": payload or {}}
        logger.info("Sending event: %s", event_name)
        return event_payload
