"""Electron shell integration helpers for the desktop assistant."""

from .bridge import ElectronBridge

__all__ = ["ElectronBridge"]
