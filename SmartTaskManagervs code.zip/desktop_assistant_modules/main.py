"""Launch the local Windows computer assistant."""

from pathlib import Path
import sys


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
	sys.path.insert(0, str(PROJECT_ROOT))

from desktop_assistant_modules.local_web import main as run_local_web_app
from desktop_assistant_modules.storage import AppStore


def main() -> None:
	store = AppStore(Path(__file__).resolve().parents[1])
	run_local_web_app(store)


if __name__ == "__main__":
	main()
