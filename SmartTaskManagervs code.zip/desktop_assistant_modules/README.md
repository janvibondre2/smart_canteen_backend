# Desktop Assistant Modules

This folder contains the backend-only modules for a desktop assistant project. It is intentionally separated from the React frontend and FastAPI backend so that your teammate can integrate it cleanly.

## Structure

- electron/: desktop shell bridge and IPC helpers
- automation/: task orchestration and workflow execution
- database/: shared database access layer
- ollama/: local LLM integration helpers
- piper/: speech synthesis integration
- chromadb/: vector database support
- sqlite/: SQLite-specific client helpers
- postgresql/: PostgreSQL-specific client helpers
- pyautogui/: desktop automation actions
- playwright/: browser automation helpers
- psutil/: system monitoring helpers
- pywin32/: Windows-specific helpers
- keyboard/: keyboard control helpers
- mouse/: mouse control helpers
- utils/: shared helpers and logging
- config/: environment and settings loading

## Notes

- All modules are written in Python.
- Electron is treated as a desktop shell only and communicates with these modules through a simple bridge.
- The structure is designed to be modular, testable, and easy to connect to another teammate's FastAPI API and React UI.
