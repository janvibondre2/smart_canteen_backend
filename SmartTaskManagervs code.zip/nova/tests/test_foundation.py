"""Unit tests for the Nova foundation."""

from pathlib import Path
import tempfile
import unittest

from nova.ai.intent import detect_intents
from nova.ai.llm import LLMError, OpenAICompatibleProvider
from nova.ai.tools import Tool, ToolRegistry
from nova.config import Settings, load_settings
from nova.database.database import Database
from nova.security.permissions import Permission


class NovaFoundationTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.database = Database(self.root / "data" / "nova.db")
        self.addCleanup(self.database.close)
        self.registry = ToolRegistry(self.database)

    def test_intents_cover_core_command_examples(self):
        cases = {
            "Open Chrome": "open_application",
            "Search Google for cybersecurity internships": "open_url",
            "Search YouTube for PyTorch tutorials": "open_url",
            "Open localhost:8000": "open_url",
            "Open Downloads": "open_folder",
            "Check system information": "system_information",
            "Close Chrome": "close_application",
        }
        for command, expected_tool in cases.items():
            with self.subTest(command=command):
                self.assertEqual(detect_intents(command)[0].tool, expected_tool)

    def test_unknown_command_is_not_interpreted_as_shell(self):
        self.assertEqual(detect_intents("powershell Remove-Item important.txt"), [])

    def test_safe_tool_runs_and_is_audited(self):
        self.registry.register(Tool("safe_test", "test", Permission.SAFE, lambda: "done"))
        result = self.registry.invoke("safe_test", "check", {})
        self.assertEqual(result, "done")
        record = self.database.recent_invocations(1)[0]
        self.assertTrue(record.success)
        self.assertEqual(record.tool_name, "safe_test")

    def test_confirmation_denial_prevents_tool_execution(self):
        executed = []
        self.registry.register(Tool("sensitive_test", "test", Permission.CONFIRM, lambda: executed.append(True) or "done"))
        result = self.registry.invoke("sensitive_test", "close app", {}, lambda *_: False)
        self.assertIn("not authorized", result)
        self.assertEqual(executed, [])
        self.assertEqual(self.database.recent_invocations(1)[0].confirmation_status, "denied")

    def test_blocked_tool_cannot_run(self):
        executed = []
        self.registry.register(Tool("blocked_test", "test", Permission.BLOCKED, lambda: executed.append(True) or "done"))
        self.registry.invoke("blocked_test", "blocked request")
        self.assertEqual(executed, [])

    def test_config_keeps_api_key_out_of_persistent_json(self):
        path = self.root / "config.json"
        settings = load_settings(path)
        settings.openai_api_key = "test-secret"
        from nova.config import save_settings
        save_settings(settings, path)
        self.assertNotIn("test-secret", path.read_text(encoding="utf-8"))

    def test_ai_provider_requires_explicit_configuration(self):
        provider = OpenAICompatibleProvider(Settings(openai_api_key=""))
        with self.assertRaises(LLMError):
            provider.answer("Explain Python")


if __name__ == "__main__":
    unittest.main()