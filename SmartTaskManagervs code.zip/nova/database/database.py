"""SQLite persistence for assistant activity."""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path

from sqlalchemy import Boolean, DateTime, Integer, String, Text, create_engine, select
from sqlalchemy.orm import DeclarativeBase, Mapped, Session, mapped_column, sessionmaker


class Base(DeclarativeBase):
    pass


class ToolInvocation(Base):
    """Auditable result of one registered tool invocation."""

    __tablename__ = "tool_invocations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    user_command: Mapped[str] = mapped_column(Text)
    tool_name: Mapped[str] = mapped_column(String(100))
    arguments_summary: Mapped[str] = mapped_column(String(300), default="")
    result: Mapped[str] = mapped_column(Text)
    success: Mapped[bool] = mapped_column(Boolean)
    confirmation_status: Mapped[str] = mapped_column(String(30), default="not_required")


class Database:
    """Own the SQLite engine and provide short-lived sessions."""

    def __init__(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        self.engine = create_engine(f"sqlite:///{path.as_posix()}", connect_args={"check_same_thread": False})
        self._sessions = sessionmaker(self.engine, expire_on_commit=False)
        Base.metadata.create_all(self.engine)

    def log_invocation(
        self,
        command: str,
        tool_name: str,
        arguments_summary: str,
        result: str,
        success: bool,
        confirmation_status: str,
    ) -> None:
        """Write one non-secret audit record."""
        with self._sessions.begin() as session:
            session.add(ToolInvocation(
                user_command=command[:2000],
                tool_name=tool_name,
                arguments_summary=arguments_summary[:300],
                result=result[:4000],
                success=success,
                confirmation_status=confirmation_status,
            ))

    def recent_invocations(self, limit: int = 50) -> list[ToolInvocation]:
        with Session(self.engine) as session:
            statement = select(ToolInvocation).order_by(ToolInvocation.id.desc()).limit(limit)
            return list(session.scalars(statement))

    def close(self) -> None:
        """Dispose pooled SQLite connections, including for temporary databases."""
        self.engine.dispose()