"""Explicit permission levels for local assistant tools."""

from __future__ import annotations

from enum import StrEnum
from typing import Callable


class Permission(StrEnum):
    SAFE = "safe"
    CONFIRM = "confirm"
    BLOCKED = "blocked"


class PermissionManager:
    """Authorize safe tools and require affirmative consent for sensitive ones."""

    def authorize(
        self,
        permission: Permission,
        tool_name: str,
        confirm: Callable[[str, str], bool] | None = None,
    ) -> tuple[bool, str]:
        if permission is Permission.BLOCKED:
            return False, "blocked"
        if permission is Permission.SAFE:
            return True, "not_required"
        if confirm is None:
            return False, "confirmation_unavailable"
        approved = confirm("Confirm action", f"Nova is requesting permission to run: {tool_name}\n\nContinue?")
        return approved, "approved" if approved else "denied"