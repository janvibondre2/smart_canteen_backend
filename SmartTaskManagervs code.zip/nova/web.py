"""Loopback-only FastAPI companion for the Nova desktop assistant."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
import threading
import uuid

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field

from nova.ai.intent import Intent, detect_intents
from nova.ai.llm import LLMError, OpenAICompatibleProvider
from nova.ai.tools import ToolRegistry
from nova.automation.windows_tools import create_windows_tools
from nova.config import APP_HOME, DATABASE_PATH, load_settings
from nova.database.database import Database
from nova.security.permissions import Permission


class CommandRequest(BaseModel):
    command: str = Field(min_length=1, max_length=2000)


class ConfirmationRequest(BaseModel):
    confirmation_id: str
    approved: bool


@dataclass
class PendingConfirmation:
    command: str
    intent: Intent
    created_at: datetime


def create_app() -> FastAPI:
    """Create a local API using the same registry and database as the desktop UI."""
    settings = load_settings()
    database = Database(DATABASE_PATH)
    registry = ToolRegistry(database)
    create_windows_tools(registry, settings)
    provider = OpenAICompatibleProvider(settings)
    pending: dict[str, PendingConfirmation] = {}
    pending_lock = threading.Lock()
    app = FastAPI(title="Nova Desktop AI Assistant", docs_url=None, redoc_url=None)
    app.state.database = database
    app.state.registry = registry
    app.state.settings = settings

    @app.middleware("http")
    async def loopback_only(request: Request, call_next):
        client = request.client.host if request.client else ""
        host = request.headers.get("host", "").split(":", 1)[0].strip("[]").lower()
        if client not in {"127.0.0.1", "::1", "testclient"} or host not in {"localhost", "127.0.0.1", "::1", "testserver"}:
            raise HTTPException(status_code=403, detail="Nova is available only from this computer.")
        return await call_next(request)

    @app.get("/", response_class=HTMLResponse)
    def home() -> str:
        return Path(__file__).with_name("web.html").read_text(encoding="utf-8")

    @app.get("/api/status")
    def status() -> dict:
        records = database.recent_invocations(30)
        with pending_lock:
            confirmations = list(pending)
        return {
            "name": "Nova Desktop AI Assistant",
            "workspace": str(settings.workspace),
            "tools": registry.names(),
            "pending_confirmations": confirmations,
            "activity": [
                {
                    "timestamp": item.timestamp.isoformat(),
                    "command": item.user_command,
                    "tool": item.tool_name,
                    "result": item.result,
                    "success": item.success,
                    "confirmation": item.confirmation_status,
                }
                for item in records
            ],
        }

    @app.post("/api/command")
    def command(request: CommandRequest) -> dict:
        intents = detect_intents(request.command)
        if not intents:
            try:
                return {"messages": [{"role": "assistant", "text": provider.answer(request.command)}], "confirmation": None}
            except LLMError as error:
                raise HTTPException(status_code=422, detail=str(error)) from error

        messages: list[dict[str, str]] = [{"role": "user", "text": request.command}]
        for intent in intents:
            tool = registry.get(intent.tool)
            if tool.permission is Permission.CONFIRM:
                confirmation_id = uuid.uuid4().hex
                with pending_lock:
                    pending[confirmation_id] = PendingConfirmation(request.command, intent, datetime.now(timezone.utc))
                return {
                    "messages": messages,
                    "confirmation": {
                        "id": confirmation_id,
                        "title": "Confirm action",
                        "details": f"Nova wants to {intent.response.lower()}\n\nThis may close the application and lose unsaved work. Continue?",
                    },
                }
            result = registry.invoke(intent.tool, request.command, intent.arguments)
            messages.append({"role": "assistant", "text": result})
        return {"messages": messages, "confirmation": None}

    @app.post("/api/confirm")
    def confirm(request: ConfirmationRequest) -> dict:
        with pending_lock:
            action = pending.pop(request.confirmation_id, None)
        if action is None:
            raise HTTPException(status_code=404, detail="Confirmation expired or already handled.")
        if (datetime.now(timezone.utc) - action.created_at).total_seconds() > 120:
            raise HTTPException(status_code=410, detail="Confirmation expired. Submit the command again.")
        tool = registry.get(action.intent.tool)
        result = registry.invoke(
            action.intent.tool,
            action.command,
            action.intent.arguments,
            lambda *_args: request.approved,
        )
        return {"result": result, "approved": request.approved, "tool": tool.name}

    @app.on_event("shutdown")
    def close_database() -> None:
        database.close()

    return app


app = create_app()


if __name__ == "__main__":
    import uvicorn

    APP_HOME.mkdir(parents=True, exist_ok=True)
    uvicorn.run(app, host="127.0.0.1", port=8765, log_level="warning")