# Nova Desktop AI Assistant

Nova is the native Windows desktop assistant for this workspace. It is separate from the Smart Task Manager web project.

## Requirements

- Windows 10/11
- Python 3.11 or later, 64-bit
- Internet access only for pip installation or an explicitly configured AI provider

## Setup and run

From the repository root, run `setup_nova.bat` once, then `start_nova.bat` for the PySide6 window or `start_nova_web.bat` for the loopback web UI. The web UI is at `http://127.0.0.1:8765` and binds only to this computer. Alternatively:

```powershell
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r nova\requirements.txt
.venv\Scripts\python.exe -m nova.main
```

## Configuration

Copy `nova/.env.example` to `nova/.env` and set `OPENAI_API_KEY` to enable AI answers through an OpenAI-compatible endpoint. Keys are read from environment and are not written to the persistent JSON settings. Settings and the SQLite database live in `%APPDATA%\Nova`.

## Current foundation

- PySide6 conversation UI with status and recent tool activity
- Deterministic intents for opening supported apps, websites/searches, standard folders, system information, and closing supported apps
- Central tool registry with safe, confirmation-required, and blocked permission levels
- SQLite audit history for every registered tool invocation
- OpenAI-compatible chat provider for natural-language answers when explicitly configured
- Optional FastAPI localhost interface sharing the same tools and SQLite audit database
- Safe app launching uses fixed executable mappings; arbitrary shell text is not executed
- Localhost UI push-to-talk voice commands in supporting browsers, plus a Nova greeting in both interfaces
- Optional spoken web replies through the browser's built-in speech synthesis

Voice recognition is available in the localhost web UI through the browser Web Speech API. Chrome/Edge support and microphone permission are required; depending on browser settings, audio may be processed by its speech-recognition service. The PySide6 window currently has text input and greeting only. Playwright workflows, file editing/deletion, reminders, scheduling, and plugin loading are not part of this first runnable foundation yet.

## Tests

```powershell
.venv\Scripts\python.exe -m unittest discover -s nova\tests -v
```

New actions belong in a focused module under `nova/`, should be registered in the tool registry with an explicit permission level, and should include unit tests before UI wiring.