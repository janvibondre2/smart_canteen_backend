"""Dark PySide6 conversation window for Nova."""

from __future__ import annotations

from datetime import timezone

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QMainWindow,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QSplitter,
    QVBoxLayout,
    QWidget,
)

from nova.ai.intent import detect_intents
from nova.ai.llm import LLMError, OpenAICompatibleProvider
from nova.ai.tools import ToolRegistry
from nova.database.database import Database
from nova.security.permissions import Permission


class MainWindow(QMainWindow):
    """Display conversation, action status, and recent tool audit records."""

    def __init__(self, registry: ToolRegistry, database: Database, llm: OpenAICompatibleProvider) -> None:
        super().__init__()
        self.registry = registry
        self.database = database
        self.llm = llm
        self.setWindowTitle("Nova Desktop AI Assistant")
        self.resize(1100, 740)
        self.setMinimumSize(800, 560)
        self.setStyleSheet("""
            QWidget { background: #111814; color: #e6eee8; font-family: 'Segoe UI'; font-size: 10pt; }
            QLineEdit, QPlainTextEdit, QListWidget { background: #19221c; border: 1px solid #34443a; border-radius: 5px; padding: 9px; }
            QPushButton { background: #253329; border: 1px solid #425448; border-radius: 5px; padding: 9px 15px; }
            QPushButton:hover { background: #34483a; }
            QPushButton#send { background: #b8e986; color: #172213; font-weight: 700; border: 0; }
            QLabel#muted { color: #a0aea4; }
        """)

        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setContentsMargins(24, 20, 24, 20)
        header = QHBoxLayout()
        title = QLabel("Nova AI ASSISTANT")
        title.setStyleSheet("font-size: 20pt; font-weight: 700;")
        self.status = QLabel("● Ready")
        self.status.setObjectName("muted")
        header.addWidget(title)
        header.addStretch(1)
        header.addWidget(self.status)
        layout.addLayout(header)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        self.conversation = QPlainTextEdit()
        self.conversation.setReadOnly(True)
        self.conversation.setPlaceholderText("Nova is ready. Try: Open Chrome, search Google for Python internships, open Downloads, or ask for system information.")
        sidebar = QWidget()
        side_layout = QVBoxLayout(sidebar)
        side_layout.setContentsMargins(12, 0, 0, 0)
        side_layout.addWidget(QLabel("RECENT ACTIONS"))
        self.activity = QListWidget()
        side_layout.addWidget(self.activity, 1)
        side_layout.addWidget(QLabel("TOOLS"))
        side_layout.addWidget(QLabel("Apps · Browser · Folders · System info"))
        settings_button = QPushButton("Settings location")
        settings_button.setToolTip("Configuration and the SQLite activity database are stored under %APPDATA%\\Nova")
        side_layout.addWidget(settings_button)
        splitter.addWidget(self.conversation)
        splitter.addWidget(sidebar)
        splitter.setSizes([740, 300])
        layout.addWidget(splitter, 1)

        command_row = QHBoxLayout()
        self.command = QLineEdit()
        self.command.setPlaceholderText("Type a command or question...")
        self.command.returnPressed.connect(self._submit)
        send = QPushButton("Send")
        send.setObjectName("send")
        send.clicked.connect(self._submit)
        command_row.addWidget(self.command, 1)
        command_row.addWidget(send)
        layout.addLayout(command_row)
        self._append("Nova", "Hello, I'm Nova. What can I help you with today?")
        self._refresh_activity()

    def _submit(self) -> None:
        text = self.command.text().strip()
        if not text:
            return
        self.command.clear()
        self._append("You", text)
        self.status.setText("● Planning")
        self.setEnabled(False)
        try:
            intents = detect_intents(text)
            if not intents:
                answer = self.llm.answer(text)
                self._append("Nova", answer)
            else:
                for intent in intents:
                    self.status.setText(f"● {intent.response}")
                    tool = self.registry.get(intent.tool)
                    def confirm(title: str, details: str) -> bool:
                        return QMessageBox.question(self, title, details, QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No) == QMessageBox.StandardButton.Yes
                    result = self.registry.invoke(
                        intent.tool,
                        text,
                        intent.arguments,
                        confirm if tool.permission is Permission.CONFIRM else None,
                    )
                    self._append("Nova", result)
        except (LLMError, KeyError, RuntimeError) as error:
            self._append("Nova", str(error))
        finally:
            self.setEnabled(True)
            self.status.setText("● Ready")
            self.command.setFocus()
            self._refresh_activity()

    def _append(self, role: str, message: str) -> None:
        self.conversation.appendPlainText(f"{role}: {message}\n")

    def _refresh_activity(self) -> None:
        self.activity.clear()
        for item in self.database.recent_invocations(15):
            timestamp = item.timestamp
            if timestamp.tzinfo is None:
                timestamp = timestamp.replace(tzinfo=timezone.utc)
            self.activity.addItem(f"{timestamp.astimezone().strftime('%H:%M:%S')}  {item.tool_name}\n{item.result[:100]}")