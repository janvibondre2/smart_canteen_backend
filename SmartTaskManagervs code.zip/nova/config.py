"""Validated, persistent settings for Nova."""

from __future__ import annotations

import json
import os
from pathlib import Path

from dotenv import load_dotenv
from pydantic import BaseModel, Field, ValidationError


APP_HOME = Path(os.getenv("APPDATA", Path.home())) / "Nova"
CONFIG_PATH = APP_HOME / "config.json"
DATABASE_PATH = APP_HOME / "data" / "nova.db"
load_dotenv(Path(__file__).with_name(".env"))


class Settings(BaseModel):
    """Application configuration with local, persistent defaults."""

    workspace: Path = Field(default_factory=Path.cwd)
    preferred_browser: str = "chrome"
    openai_base_url: str = "https://api.openai.com/v1"
    openai_model: str = "gpt-4o-mini"
    openai_api_key: str = ""
    tts_enabled: bool = False
    stt_enabled: bool = False
    wake_word_enabled: bool = False


def load_settings(path: Path = CONFIG_PATH) -> Settings:
    """Load JSON settings and environment overrides without logging secrets."""
    try:
        values = json.loads(path.read_text(encoding="utf-8")) if path.is_file() else {}
    except (OSError, json.JSONDecodeError):
        values = {}
    if not isinstance(values, dict):
        values = {}
    values.update({
        "openai_api_key": os.getenv("OPENAI_API_KEY", values.get("openai_api_key", "")),
        "openai_base_url": os.getenv("OPENAI_BASE_URL", values.get("openai_base_url", "https://api.openai.com/v1")),
        "openai_model": os.getenv("LLM_MODEL", values.get("openai_model", "gpt-4o-mini")),
    })
    try:
        settings = Settings.model_validate(values)
    except ValidationError:
        settings = Settings()
    save_settings(settings, path)
    return settings


def save_settings(settings: Settings, path: Path = CONFIG_PATH) -> None:
    """Persist non-secret preferences; API keys remain in environment variables."""
    path.parent.mkdir(parents=True, exist_ok=True)
    values = settings.model_dump(mode="json")
    values.pop("openai_api_key", None)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(values, indent=2), encoding="utf-8")
    temporary.replace(path)