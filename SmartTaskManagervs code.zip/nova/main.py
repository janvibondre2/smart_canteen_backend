"""Start the Nova PySide6 application."""

from __future__ import annotations

import sys
import argparse

from PySide6.QtWidgets import QApplication

from nova.ai.llm import OpenAICompatibleProvider
from nova.ai.tools import ToolRegistry
from nova.automation.windows_tools import create_windows_tools
from nova.config import DATABASE_PATH, load_settings
from nova.database.database import Database
from nova.gui.main_window import MainWindow


def main() -> int:
    settings = load_settings()
    database = Database(DATABASE_PATH)
    registry = ToolRegistry(database)
    create_windows_tools(registry, settings)
    application = QApplication(sys.argv)
    application.setApplicationName("Nova Desktop AI Assistant")
    window = MainWindow(registry, database, OpenAICompatibleProvider(settings))
    window.show()
    return application.exec()


if __name__ == "__main__":
    raise SystemExit(main())