"""Central registry for permission-checked assistant tools."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from nova.database.database import Database
from nova.security.permissions import Permission, PermissionManager


class ToolError(RuntimeError):
    pass


@dataclass(frozen=True)
class Tool:
    name: str
    description: str
    permission: Permission
    execute: Callable[..., str]


class ToolRegistry:
    """Register, inspect, authorize, execute, and audit tools."""

    def __init__(self, database: Database, permissions: PermissionManager | None = None) -> None:
        self.database = database
        self.permissions = permissions or PermissionManager()
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool) -> None:
        if tool.name in self._tools:
            raise ValueError(f"Tool already registered: {tool.name}")
        self._tools[tool.name] = tool

    def names(self) -> tuple[str, ...]:
        return tuple(sorted(self._tools))

    def get(self, name: str) -> Tool:
        """Return a registered tool by name."""
        try:
            return self._tools[name]
        except KeyError as error:
            raise ToolError(f"Unknown tool: {name}") from error

    def invoke(
        self,
        name: str,
        command: str,
        arguments: dict[str, Any] | None = None,
        confirm: Callable[[str, str], bool] | None = None,
    ) -> str:
        tool = self.get(name)
        arguments = arguments or {}
        allowed, confirmation_status = self.permissions.authorize(tool.permission, name, confirm)
        if not allowed:
            result = f"Action not authorized ({confirmation_status})."
            self.database.log_invocation(command, name, "parameters omitted", result, False, confirmation_status)
            return result
        try:
            result = tool.execute(**arguments)
        except Exception as error:
            result = f"Failed: {error}"
            self.database.log_invocation(command, name, "parameters omitted", result, False, confirmation_status)
            return result
        self.database.log_invocation(command, name, "parameters omitted", result, True, confirmation_status)
        return result