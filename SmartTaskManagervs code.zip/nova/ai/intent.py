"""Small, deterministic intent parser used before optional LLM planning."""

from __future__ import annotations

from dataclasses import dataclass
import re
from urllib.parse import quote_plus


@dataclass(frozen=True)
class Intent:
    tool: str
    arguments: dict[str, str]
    response: str


def detect_intents(command: str) -> list[Intent]:
    """Recognize supported launch, navigation, folder, and information requests."""
    text = command.strip()
    normalized = text.lower()
    if not text:
        return []

    actions: list[Intent] = []
    app_patterns = (
        (r"\b(?:open|launch|start|switch to)\s+(?:google\s+)?chrome\b", "chrome", "Chrome"),
        (r"\b(?:open|launch|start|switch to)\s+(?:microsoft\s+)?teams\b", "teams", "Microsoft Teams"),
        (r"\b(?:open|launch|start|switch to)\s+(?:vs\s*code|vscode|visual\s+studio\s+code)\b", "vscode", "Visual Studio Code"),
        (r"\b(?:open|launch|start)\s+(?:file\s+)?explorer\b", "explorer", "File Explorer"),
        (r"\b(?:open|launch|start)\s+(?:windows\s+)?terminal\b", "terminal", "Windows Terminal"),
        (r"\b(?:open|launch|start|switch to)\s+(?:microsoft\s+)?edge\b", "edge", "Microsoft Edge"),
    )
    for pattern, application, label in app_patterns:
        if re.search(pattern, normalized):
            actions.append(Intent("open_application", {"application": application}, f"Opening {label}."))

    close_app = re.search(r"\bclose\s+(chrome|edge|(?:microsoft\s+)?teams|(?:vs\s*code|vscode|visual\s+studio\s+code))\b", normalized)
    if close_app:
        target = close_app.group(1).replace("microsoft ", "")
        application = "vscode" if target in {"vs code", "vscode", "visual studio code"} else target
        actions.append(Intent("close_application", {"application": application}, f"Closing {application}."))

    youtube = re.search(r"(?:search\s+)?youtube\s+for\s+(.+)$", text, re.IGNORECASE)
    google = re.search(r"(?:search\s+)?google\s+for\s+(.+)$", text, re.IGNORECASE)
    generic_search = re.search(r"search\s+(.+?)\s+on\s+google\b", text, re.IGNORECASE)
    search = youtube or google or generic_search
    if search:
        query = search.group(1).strip(" \"'")
        is_youtube = youtube is not None
        base = "https://www.youtube.com/results?search_query=" if is_youtube else "https://www.google.com/search?q="
        actions.append(Intent("open_url", {"url": base + quote_plus(query)}, f"Searching {'YouTube' if is_youtube else 'Google'} for {query}."))
    elif re.search(r"\b(?:open|go to|navigate to)\s+(?:youtube|youtube\.com)\b", normalized):
        actions.append(Intent("open_url", {"url": "https://www.youtube.com"}, "Opening YouTube."))
    elif re.search(r"\b(?:open|go to|navigate to)\s+(?:google|google\.com)\b", normalized):
        actions.append(Intent("open_url", {"url": "https://www.google.com"}, "Opening Google."))
    else:
        local = re.search(r"\b(?:open|go to)\s+(localhost(?::\d+)?(?:/[^\s]*)?)", text, re.IGNORECASE)
        url = re.search(r"\b(?:open|go to)\s+(https?://[^\s]+|www\.[^\s]+)", text, re.IGNORECASE)
        if local:
            actions.append(Intent("open_url", {"url": "http://" + local.group(1)}, "Opening your local server."))
        elif url:
            target = url.group(1).rstrip(".,)")
            actions.append(Intent("open_url", {"url": target if target.startswith("http") else "https://" + target}, "Opening website."))

    folder = re.search(r"\bopen\s+(downloads|documents|desktop|home)\b", normalized)
    if folder:
        actions.append(Intent("open_folder", {"folder": folder.group(1)}, f"Opening {folder.group(1)}."))
    if "system information" in normalized or normalized in {"system info", "what are my system specs"}:
        actions.append(Intent("system_information", {}, "Checking basic system information."))
    return actions