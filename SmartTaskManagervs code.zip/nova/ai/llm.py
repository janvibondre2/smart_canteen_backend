"""OpenAI-compatible chat provider, used only for user-facing answers."""

from __future__ import annotations

import json
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from nova.config import Settings


class LLMError(RuntimeError):
    pass


class OpenAICompatibleProvider:
    """Minimal configurable chat-completions client with no key persistence."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings

    def answer(self, prompt: str) -> str:
        if not self.settings.openai_api_key:
            raise LLMError("No AI provider is configured. Set OPENAI_API_KEY in nova/.env to enable AI answers.")
        body = json.dumps({
            "model": self.settings.openai_model,
            "messages": [
                {"role": "system", "content": "You are Nova, a concise Windows desktop assistant. Never claim to have performed computer actions."},
                {"role": "user", "content": prompt[:8000]},
            ],
            "temperature": 0.3,
        }).encode("utf-8")
        request = Request(
            f"{self.settings.openai_base_url.rstrip('/')}/chat/completions",
            data=body,
            headers={"Content-Type": "application/json", "Authorization": f"Bearer {self.settings.openai_api_key}"},
            method="POST",
        )
        try:
            with urlopen(request, timeout=30) as response:
                result = json.loads(response.read().decode("utf-8"))
            return str(result["choices"][0]["message"]["content"]).strip()
        except (HTTPError, URLError, TimeoutError, OSError, ValueError, KeyError, IndexError) as error:
            raise LLMError(f"AI provider request failed: {error}") from error