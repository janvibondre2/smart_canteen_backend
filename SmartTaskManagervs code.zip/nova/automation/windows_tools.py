"""Explicitly allow-listed Windows application and browser controls."""

from __future__ import annotations

import os
from pathlib import Path
import platform
import shutil
import subprocess
import webbrowser

from nova.ai.tools import Tool, ToolRegistry
from nova.config import Settings
from nova.security.permissions import Permission


APP_LABELS = {
    "chrome": "Google Chrome",
    "edge": "Microsoft Edge",
    "teams": "Microsoft Teams",
    "vscode": "Visual Studio Code",
    "explorer": "File Explorer",
    "terminal": "Windows Terminal",
}


def _candidate_paths(application: str) -> list[Path]:
    local = Path(os.getenv("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    program_files = Path(os.getenv("ProgramFiles", r"C:\Program Files"))
    program_files_x86 = Path(os.getenv("ProgramFiles(x86)", r"C:\Program Files (x86)"))
    candidates = {
        "chrome": [program_files / "Google/Chrome/Application/chrome.exe", program_files_x86 / "Google/Chrome/Application/chrome.exe", local / "Google/Chrome/Application/chrome.exe"],
        "edge": [program_files_x86 / "Microsoft/Edge/Application/msedge.exe", program_files / "Microsoft/Edge/Application/msedge.exe"],
        "vscode": [local / "Programs/Microsoft VS Code/Code.exe", program_files / "Microsoft VS Code/Code.exe"],
    }
    return candidates.get(application, [])


def create_windows_tools(registry: ToolRegistry, settings: Settings) -> None:
    """Register the first safe Windows control tools."""
    def open_application(application: str) -> str:
        application = application.lower().strip()
        if application not in APP_LABELS:
            raise ValueError("That application is not in the supported application list.")
        if application == "teams":
            if os.name == "nt" and hasattr(os, "startfile"):
                try:
                    os.startfile("msteams:")
                    return "Opened Microsoft Teams. Sign-in remains under your control."
                except OSError:
                    webbrowser.open("https://teams.microsoft.com")
                    return "Opened Teams in your browser; sign in normally if prompted."
            webbrowser.open("https://teams.microsoft.com")
            return "Opened Teams in your browser; sign in normally if prompted."

        if application == "explorer":
            if os.name != "nt":
                raise OSError("File Explorer is available only on Windows.")
            subprocess.Popen(["explorer.exe", str(settings.workspace)])
            return "Opened File Explorer at the configured workspace."

        if application == "terminal":
            terminal = shutil.which("wt.exe") or shutil.which("wt")
            command = [terminal] if terminal else ["powershell.exe"]
            subprocess.Popen(command, cwd=str(settings.workspace))
            return "Opened a terminal in the configured workspace."

        executable = next((path for path in _candidate_paths(application) if path.is_file()), None)
        if executable:
            subprocess.Popen([str(executable), str(settings.workspace)] if application == "vscode" else [str(executable)])
            return f"Opened {APP_LABELS[application]}."
        command = shutil.which({"chrome": "chrome.exe", "edge": "msedge.exe", "vscode": "code"}[application])
        if command:
            subprocess.Popen([command, str(settings.workspace)] if application == "vscode" else [command])
            return f"Opened {APP_LABELS[application]}."
        if application in {"chrome", "edge"}:
            webbrowser.open("https://www.google.com")
            return f"Could not find {APP_LABELS[application]}; opened the system default browser instead."
        raise FileNotFoundError(f"Could not locate {APP_LABELS[application]}.")

    def open_url(url: str) -> str:
        from urllib.parse import urlsplit

        parsed = urlsplit(url)
        if parsed.scheme not in {"http", "https"} or not parsed.hostname:
            raise ValueError("Only valid HTTP or HTTPS URLs are allowed.")
        opened = webbrowser.open(url, new=2)
        if not opened:
            raise OSError("The default browser did not accept the URL.")
        return f"Opened {url}."

    def open_folder(folder: str) -> str:
        known = {
            "home": Path.home(),
            "desktop": Path.home() / "Desktop",
            "documents": Path.home() / "Documents",
            "downloads": Path.home() / "Downloads",
        }
        if folder not in known:
            raise ValueError("Only Home, Desktop, Documents, and Downloads are supported.")
        target = known[folder]
        if not target.is_dir():
            raise FileNotFoundError(f"Folder not found: {target}")
        if os.name != "nt":
            raise OSError("Opening Windows folders requires Windows Explorer.")
        subprocess.Popen(["explorer.exe", str(target)])
        return f"Opened {target}."

    def close_application(application: str) -> str:
        executable_names = {
            "chrome": "chrome.exe",
            "edge": "msedge.exe",
            "teams": "ms-teams.exe",
            "vscode": "Code.exe",
        }
        if os.name != "nt":
            raise OSError("Closing applications is supported only on Windows.")
        if application not in executable_names:
            raise ValueError("Only Chrome, Edge, Teams, and VS Code can be closed.")
        result = subprocess.run(
            ["taskkill.exe", "/IM", executable_names[application], "/T"],
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode:
            detail = (result.stderr or result.stdout).strip()
            if "not found" in detail.lower():
                return f"{APP_LABELS[application]} is not running."
            raise OSError(detail or "Windows could not close the application.")
        return f"Asked Windows to close {APP_LABELS[application]}."

    def system_information() -> str:
        disk = shutil.disk_usage(Path.home())
        return (
            f"{platform.system()} {platform.release()} ({platform.machine()}), "
            f"Python {platform.python_version()}, {os.cpu_count() or 'unknown'} logical CPUs, "
            f"{disk.free // (1024 ** 3)} GB free disk space."
        )

    registry.register(Tool("open_application", "Launch an allow-listed desktop app", Permission.SAFE, open_application))
    registry.register(Tool("open_url", "Navigate to a validated HTTP(S) URL", Permission.SAFE, open_url))
    registry.register(Tool("open_folder", "Open one of the user's standard folders", Permission.SAFE, open_folder))
    registry.register(Tool("system_information", "Read basic non-sensitive system information", Permission.SAFE, system_information))
    registry.register(Tool("close_application", "Close a supported app; may lose unsaved work", Permission.CONFIRM, close_application))