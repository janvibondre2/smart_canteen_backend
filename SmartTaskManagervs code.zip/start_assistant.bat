@echo off
setlocal
cd /d "%~dp0"
python "%~dp0desktop_assistant_modules\main.py"
if errorlevel 1 (
    echo The assistant could not start. Check that Python 3 and Tkinter are installed.
    pause
)