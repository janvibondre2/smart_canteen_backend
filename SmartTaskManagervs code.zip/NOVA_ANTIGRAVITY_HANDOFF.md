# Nova Assistant: Antigravity Handoff

## Current state

Nova is a runnable Windows assistant foundation in `nova/`, separate from the Smart Task Manager project. It has a PySide6 desktop window and a localhost web UI. The web UI supports push-to-talk voice commands in browsers that implement the Web Speech API, optional spoken replies, and a conversational greeting. Microphone permission is requested by the browser; audio handling depends on browser speech-service settings.

Implemented command tools are allow-listed: open supported applications, open validated HTTP(S) URLs, open standard folders, read basic system information, and close supported apps only after explicit confirmation. Tool calls are permission-checked and stored in a local SQLite audit log. Unknown commands are not sent to a shell.

## Technology stack

- Python 3.13 64-bit in the current workspace; project setup targets Python 3.11+
- PySide6 for the native desktop window
- FastAPI and Uvicorn for the localhost interface at `http://127.0.0.1:8765`
- SQLAlchemy 2 and SQLite for tool invocation audit history
- Pydantic 2 for settings and request validation
- python-dotenv for optional environment configuration
- HTML, CSS, and JavaScript for the localhost page
- Browser Web Speech API for voice input and SpeechSynthesis for optional spoken replies
- unittest for the foundation tests

## Run options

1. `setup_nova.bat` creates/updates `.venv`, installs `nova/requirements.txt`, and copies `nova/.env.example` to `nova/.env` if missing.
2. `start_nova.bat` launches the PySide6 desktop window.
3. `start_nova_web.bat` runs the loopback-only web app at `http://127.0.0.1:8765`.
4. Direct commands from the repository root:

```powershell
.venv\Scripts\python.exe -m nova.main
.venv\Scripts\python.exe -m nova.web
.venv\Scripts\python.exe -m unittest discover -s nova\tests -v
```

The generated source ZIP excludes `.venv`, `.env`, `__pycache__`, and `.pyc` files. Install dependencies after extracting by running `setup_nova.bat`.

## LLM status: important accuracy note

Nova does **not** contain or train an LLM from scratch. `nova/ai/llm.py` is a small OpenAI-compatible chat-completions client. Natural-language computer actions currently use a deterministic, allow-listed intent parser; the optional provider answers general questions when the user configures `OPENAI_API_KEY`, `OPENAI_BASE_URL`, and `LLM_MODEL` in `nova/.env`.

Training a new LLM from scratch would require a large curated text corpus, tokenizer, transformer implementation, distributed training infrastructure, substantial accelerator compute, evaluation/red-teaming, and model-serving optimization. That is a separate research project, not a feature implemented here. For a local/private model, the practical next step is an adapter to a user-installed local inference server (for example, an OpenAI-compatible local endpoint), not claiming that this application built the model itself.

## Suggested next work for Antigravity

Continue incrementally. First make voice behavior robust across supported Chrome/Edge versions and add tests for command parsing and permission decisions. Then move long-running actions off the PySide UI thread, add user-editable settings, and implement one new capability at a time with tests. Do not add broad shell execution, unattended microphone listening, or recurring automation without explicit permission controls.

## Current verification

- `python -m unittest discover -s nova/tests -v`: 7 tests pass
- `python -m compileall -q nova`: passes
- Live localhost `GET /api/status` and safe `system info` command were verified
- Browser microphone behavior requires a real browser microphone permission/device and was not end-to-end tested in the automated run