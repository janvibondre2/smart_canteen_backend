@echo off
setlocal
where python >nul 2>nul
if errorlevel 1 (
    echo Python was not found. Install Python 3.10 or later and enable the Python launcher/PATH option.
    exit /b 1
)
python -c "import sys; assert sys.version_info >= (3, 10); print('Python', sys.version.split()[0], 'is ready.')"
if errorlevel 1 (
    echo This assistant requires Python 3.10 or later.
    exit /b 1
)
if not exist "%USERPROFILE%\AI_Assistant\projects\python" mkdir "%USERPROFILE%\AI_Assistant\projects\python"
if not exist "%USERPROFILE%\AI_Assistant\projects\web" mkdir "%USERPROFILE%\AI_Assistant\projects\web"
if not exist "%USERPROFILE%\AI_Assistant\projects\cybersecurity" mkdir "%USERPROFILE%\AI_Assistant\projects\cybersecurity"
if not exist "%USERPROFILE%\AI_Assistant\projects\ai_ml" mkdir "%USERPROFILE%\AI_Assistant\projects\ai_ml"
if not exist "%USERPROFILE%\AI_Assistant\projects\scripts" mkdir "%USERPROFILE%\AI_Assistant\projects\scripts"
if not exist "%USERPROFILE%\AI_Assistant\logs" mkdir "%USERPROFILE%\AI_Assistant\logs"
if not exist "%USERPROFILE%\AI_Assistant\config" mkdir "%USERPROFILE%\AI_Assistant\config"
echo Assistant workspace created at %USERPROFILE%\AI_Assistant
echo Run start_assistant.bat to open the desktop assistant.